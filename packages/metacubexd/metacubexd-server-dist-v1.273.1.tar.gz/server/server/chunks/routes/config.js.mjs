import { d as defineEventHandler, b as serverEnv, a as setHeader } from '../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:fs/promises';
import 'yaml';
import 'node:worker_threads';
import 'node:child_process';
import 'tree-kill';
import 'node:url';

const config_js = defineEventHandler((event) => {
  const { controlToken, clashSecret, githubToken, defaultBackendURL } = serverEnv();
  const config = { defaultBackendURL };
  if (controlToken) config.controlToken = controlToken;
  if (clashSecret) config.defaultBackendSecret = clashSecret;
  if (githubToken) config.githubToken = githubToken;
  setHeader(event, "content-type", "text/javascript; charset=utf-8");
  setHeader(event, "cache-control", "no-store");
  return `window.__METACUBEXD_CONFIG__ = ${JSON.stringify(config)}
`;
});

export { config_js as default };
//# sourceMappingURL=config.js.mjs.map
