import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { readFile, stat } from 'node:fs/promises';
import { join, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { d as defineEventHandler, c as createError, s as serveStatic, a as setHeader } from '../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:crypto';
import 'yaml';
import 'node:worker_threads';
import 'node:child_process';
import 'tree-kill';

const uiDist = process.env.UI_DIST || fileURLToPath(new URL("../../packages/ui/.output/public", globalThis._importMeta_.url));
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".wasm": "application/wasm",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".txt": "text/plain; charset=utf-8",
  ".map": "application/json; charset=utf-8"
};
const _____ = defineEventHandler(async (event) => {
  if (event.path.startsWith("/api/control")) {
    throw createError({ statusCode: 404, statusMessage: "Not Found" });
  }
  if (event.method !== "GET" && event.method !== "HEAD") {
    throw createError({ statusCode: 405, statusMessage: "Method Not Allowed" });
  }
  const served = await serveStatic(event, {
    fallthrough: true,
    getContents: (id) => readFile(join(uiDist, id)),
    getMeta: async (id) => {
      const stats = await stat(join(uiDist, id)).catch(() => null);
      if (!(stats == null ? void 0 : stats.isFile())) return void 0;
      return {
        type: MIME[extname(id).toLowerCase()],
        size: stats.size,
        mtime: stats.mtimeMs,
        etag: `W/"${stats.size}-${Math.round(stats.mtimeMs)}"`
      };
    }
  });
  if (served !== false) return served;
  const html = await readFile(join(uiDist, "index.html"), "utf8");
  setHeader(event, "content-type", "text/html; charset=utf-8");
  return html;
});

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
