import { d as defineEventHandler, f as fromNodeMiddleware, t as toNodeListener, g as getAgent } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:fs/promises';
import 'yaml';
import 'node:worker_threads';
import 'node:child_process';
import 'tree-kill';
import 'node:url';

const listener = toNodeListener(getAgent().router);
const _____ = defineEventHandler(
  fromNodeMiddleware((req, res, _next) => {
    listener(req, res);
  })
);

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
