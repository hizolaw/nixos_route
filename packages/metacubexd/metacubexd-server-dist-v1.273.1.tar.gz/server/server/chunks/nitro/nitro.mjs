import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { createHash, randomUUID, randomBytes } from 'node:crypto';
import { mkdir, writeFile as writeFile$1, rm, readFile as readFile$1, copyFile, rename } from 'node:fs/promises';
import { parseDocument, isMap, parse, stringify as stringify$1 } from 'yaml';
import { Worker } from 'node:worker_threads';
import { spawn } from 'node:child_process';
import treeKillDefault from 'tree-kill';
import { fileURLToPath } from 'node:url';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function decode(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/");
  }
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/") ? input : input + "/";
  }
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length).replace(/^\/+/, "");
  return "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject$1(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject$1(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject$1(value) && isPlainObject$1(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c=class{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c.prototype,i$1.prototype),Object.assign(c.prototype,l$1.prototype),c}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const ParsedBodySymbol = Symbol.for("h3ParsedBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
async function readBody(event, options = {}) {
  const request = event.node.req;
  if (hasProp(request, ParsedBodySymbol)) {
    return request[ParsedBodySymbol];
  }
  const contentType = request.headers["content-type"] || "";
  const body = await readRawBody(event);
  let parsed;
  if (contentType === "application/json") {
    parsed = _parseJSON(body, options.strict ?? true);
  } else if (contentType.startsWith("application/x-www-form-urlencoded")) {
    parsed = _parseURLEncodedBody(body);
  } else if (contentType.startsWith("text/")) {
    parsed = body;
  } else {
    parsed = _parseJSON(body, options.strict ?? false);
  }
  request[ParsedBodySymbol] = parsed;
  return parsed;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function _parseJSON(body = "", strict) {
  if (!body) {
    return void 0;
  }
  try {
    return destr(body, { strict });
  } catch {
    throw createError$1({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid JSON body"
    });
  }
}
function _parseURLEncodedBody(body) {
  const form = new URLSearchParams(body);
  const parsedForm = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of form.entries()) {
    if (hasProp(parsedForm, key)) {
      if (!Array.isArray(parsedForm[key])) {
        parsedForm[key] = [parsedForm[key]];
      }
      parsedForm[key].push(value);
    } else {
      parsedForm[key] = value;
    }
  }
  return parsedForm;
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

function formatEventStreamMessage(message) {
  let result = "";
  if (message.id) {
    result += `id: ${_sanitizeSingleLine(message.id)}
`;
  }
  if (message.event) {
    result += `event: ${_sanitizeSingleLine(message.event)}
`;
  }
  if (typeof message.retry === "number" && Number.isInteger(message.retry)) {
    result += `retry: ${message.retry}
`;
  }
  const data = typeof message.data === "string" ? message.data : "";
  for (const line of data.split(/\r\n|\r|\n/)) {
    result += `data: ${line}
`;
  }
  result += "\n";
  return result;
}
function _sanitizeSingleLine(value) {
  return value.replace(/[\n\r]/g, "");
}
function formatEventStreamMessages(messages) {
  let result = "";
  for (const msg of messages) {
    result += formatEventStreamMessage(msg);
  }
  return result;
}
function setEventStreamHeaders(event) {
  const headers = {
    "Content-Type": "text/event-stream",
    "Cache-Control": "private, no-cache, no-store, no-transform, must-revalidate, max-age=0",
    "X-Accel-Buffering": "no"
    // prevent nginx from buffering the response
  };
  if (!isHttp2Request(event)) {
    headers.Connection = "keep-alive";
  }
  setResponseHeaders(event, headers);
}
function isHttp2Request(event) {
  return getHeader(event, ":path") !== void 0 && getHeader(event, ":method") !== void 0;
}

class EventStream {
  _h3Event;
  _transformStream = new TransformStream();
  _writer;
  _encoder = new TextEncoder();
  _writerIsClosed = false;
  _paused = false;
  _unsentData;
  _disposed = false;
  _handled = false;
  constructor(event, opts = {}) {
    this._h3Event = event;
    this._writer = this._transformStream.writable.getWriter();
    this._writer.closed.then(() => {
      this._writerIsClosed = true;
    });
    if (opts.autoclose !== false) {
      this._h3Event.node.req.on("close", () => this.close());
    }
  }
  async push(message) {
    if (typeof message === "string") {
      await this._sendEvent({ data: message });
      return;
    }
    if (Array.isArray(message)) {
      if (message.length === 0) {
        return;
      }
      if (typeof message[0] === "string") {
        const msgs = [];
        for (const item of message) {
          msgs.push({ data: item });
        }
        await this._sendEvents(msgs);
        return;
      }
      await this._sendEvents(message);
      return;
    }
    await this._sendEvent(message);
  }
  async _sendEvent(message) {
    if (this._writerIsClosed) {
      return;
    }
    if (this._paused && !this._unsentData) {
      this._unsentData = formatEventStreamMessage(message);
      return;
    }
    if (this._paused) {
      this._unsentData += formatEventStreamMessage(message);
      return;
    }
    await this._writer.write(this._encoder.encode(formatEventStreamMessage(message))).catch();
  }
  async _sendEvents(messages) {
    if (this._writerIsClosed) {
      return;
    }
    const payload = formatEventStreamMessages(messages);
    if (this._paused && !this._unsentData) {
      this._unsentData = payload;
      return;
    }
    if (this._paused) {
      this._unsentData += payload;
      return;
    }
    await this._writer.write(this._encoder.encode(payload)).catch();
  }
  pause() {
    this._paused = true;
  }
  get isPaused() {
    return this._paused;
  }
  async resume() {
    this._paused = false;
    await this.flush();
  }
  async flush() {
    if (this._writerIsClosed) {
      return;
    }
    if (this._unsentData?.length) {
      await this._writer.write(this._encoder.encode(this._unsentData));
      this._unsentData = void 0;
    }
  }
  /**
   * Close the stream and the connection if the stream is being sent to the client
   */
  async close() {
    if (this._disposed) {
      return;
    }
    if (!this._writerIsClosed) {
      try {
        await this._writer.close();
      } catch {
      }
    }
    if (this._h3Event._handled && this._handled && !this._h3Event.node.res.closed) {
      this._h3Event.node.res.end();
    }
    this._disposed = true;
  }
  /**
   * Triggers callback when the writable stream is closed.
   * It is also triggered after calling the `close()` method.
   */
  onClosed(cb) {
    this._writer.closed.then(cb);
  }
  async send() {
    setEventStreamHeaders(this._h3Event);
    setResponseStatus(this._h3Event, 200);
    this._h3Event._handled = true;
    this._handled = true;
    await sendStream(this._h3Event, this._transformStream.readable);
  }
}

function createEventStream(event, opts) {
  return new EventStream(event, opts);
}

async function serveStatic(event, options) {
  if (event.method !== "GET" && event.method !== "HEAD") {
    if (!options.fallthrough) {
      throw createError$1({
        statusMessage: "Method Not Allowed",
        statusCode: 405
      });
    }
    return false;
  }
  const originalId = withLeadingSlash(
    withoutTrailingSlash(parseURL(event.path).pathname)
  );
  if (/(^|[\\/])(\.\.|%2e%2e|%2e\.|\.%2e)($|[\\/])/i.test(originalId)) {
    if (!options.fallthrough) {
      throw createError$1({ statusCode: 404 });
    }
    return false;
  }
  const acceptEncodings = parseAcceptEncoding(
    getRequestHeader(event, "accept-encoding"),
    options.encodings
  );
  if (acceptEncodings.length > 1) {
    setResponseHeader(event, "vary", "accept-encoding");
  }
  let id = originalId;
  let meta;
  const _ids = idSearchPaths(
    originalId,
    acceptEncodings,
    options.indexNames || ["/index.html"]
  );
  for (const _id of _ids) {
    const _meta = await options.getMeta(_id);
    if (_meta) {
      meta = _meta;
      id = _id;
      break;
    }
  }
  if (!meta) {
    if (!options.fallthrough) {
      throw createError$1({ statusCode: 404 });
    }
    return false;
  }
  if (meta.etag && !getResponseHeader(event, "etag")) {
    setResponseHeader(event, "etag", meta.etag);
  }
  const ifNotMatch = meta.etag && getRequestHeader(event, "if-none-match") === meta.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return send(event, "");
  }
  if (meta.mtime) {
    const mtimeDate = new Date(meta.mtime);
    const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
    if (ifModifiedSinceH && new Date(ifModifiedSinceH) >= mtimeDate) {
      setResponseStatus(event, 304, "Not Modified");
      return send(event, null);
    }
    if (!getResponseHeader(event, "last-modified")) {
      setResponseHeader(event, "last-modified", mtimeDate.toUTCString());
    }
  }
  if (meta.type && !getResponseHeader(event, "content-type")) {
    setResponseHeader(event, "content-type", meta.type);
  }
  if (meta.encoding && !getResponseHeader(event, "content-encoding")) {
    setResponseHeader(event, "content-encoding", meta.encoding);
  }
  if (meta.size !== void 0 && meta.size > 0 && !getResponseHeader(event, "content-length")) {
    setResponseHeader(event, "content-length", meta.size);
  }
  if (event.method === "HEAD") {
    return send(event, null);
  }
  const contents = await options.getContents(id);
  return isStream(contents) ? sendStream(event, contents) : send(event, contents);
}
function parseAcceptEncoding(header, encodingMap) {
  if (!encodingMap || !header) {
    return [];
  }
  return String(header || "").split(",").map((e) => encodingMap[e.trim()]).filter(Boolean);
}
function idSearchPaths(id, encodings, indexNames) {
  const ids = [];
  for (const suffix of ["", ...indexNames]) {
    for (const encoding of [...encodings, ""]) {
      ids.push(`${id}${suffix}${encoding}`);
    }
  }
  return ids;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function fromNodeMiddleware(handler) {
  if (isEventHandler(handler)) {
    return handler;
  }
  if (typeof handler !== "function") {
    throw new TypeError(
      "Invalid handler. It should be a function:",
      handler
    );
  }
  return eventHandler((event) => {
    return callNodeListener(
      handler,
      event.node.req,
      event.node.res
    );
  });
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}
function callNodeListener(handler, req, res) {
  const isMiddleware = handler.length > 2;
  return new Promise((resolve, reject) => {
    const next = (err) => {
      if (isMiddleware) {
        res.off("close", next);
        res.off("error", next);
      }
      return err ? reject(createError$1(err)) : resolve(void 0);
    };
    try {
      const returned = handler(req, res, next);
      if (isMiddleware && returned === void 0) {
        res.once("close", next);
        res.once("error", next);
      } else {
        resolve(returned);
      }
    } catch (error) {
      next(error);
    }
  });
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch$1 = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
createFetch({ fetch: fetch$1, Headers: Headers$1, AbortController });

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/"
  },
  "nitro": {
    "routeRules": {}
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  {
    return _sharedRuntimeConfig;
  }
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());

getContext("nitro-app", {
  asyncContext: undefined,
  AsyncLocalStorage: void 0
});

function isPathInScope(pathname, base) {
  let canonical;
  try {
    const pre = pathname.replace(/%2f/gi, "/").replace(/%5c/gi, "\\");
    canonical = new URL(pre, "http://_").pathname;
  } catch {
    return false;
  }
  return !base || canonical === base || canonical.startsWith(base + "/");
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$0 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const GEO_ASSET_URLS = {
  "geoip.dat": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.dat",
  "geosite.dat": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.dat",
  "country.mmdb": "https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/country.mmdb"
};
const GEO_FILES = Object.keys(GEO_ASSET_URLS);
async function fetchGeoAssets(destDir, deps = {}) {
  var _a;
  const doFetch = (_a = deps.fetch) != null ? _a : fetch;
  await mkdir(destDir, { recursive: true });
  const files = [];
  for (const file of GEO_FILES) {
    const url = GEO_ASSET_URLS[file];
    const res = await doFetch(url);
    if (!res.ok) {
      throw new Error(
        `fetchGeoAssets: download failed ${res.status} for ${file} (${url})`
      );
    }
    const bytes = Buffer$1.from(await res.arrayBuffer());
    await writeFile$1(join(destDir, file), bytes);
    files.push(file);
  }
  return { files };
}

var __defProp$4 = Object.defineProperty;
var __defNormalProp$4 = (obj, key, value) => key in obj ? __defProp$4(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$4 = (obj, key, value) => __defNormalProp$4(obj, key + "" , value);
class ConfigDocumentError extends Error {
  constructor(message, errors) {
    super(message);
    __publicField$4(this, "errors", errors);
    this.name = "ConfigDocumentError";
  }
}
const NAMED_ARRAYS = {
  proxies: "name",
  "proxy-groups": "name",
  listeners: "name",
  tunnels: "network"
};
const NAMED_MAPS = /* @__PURE__ */ new Set([
  "proxy-providers",
  "rule-providers",
  "sub-rules",
  "hosts"
]);
function isObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function clone(value) {
  if (Array.isArray(value)) return value.map((item) => clone(item));
  if (isObject(value)) {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [key, clone(item)])
    );
  }
  return value;
}
function canonical(value) {
  if (value === void 0) return "undefined";
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (isObject(value)) {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
function hashConfigValue(value) {
  const input = canonical(value);
  let hash = 2166136261;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}
function parseYaml(yaml) {
  const doc = parseDocument(yaml, { prettyErrors: true, uniqueKeys: true });
  const errors = doc.errors.map((error) => error.message);
  if (errors.length) {
    throw new ConfigDocumentError("Invalid YAML configuration", errors);
  }
  if (!isMap(doc.contents)) {
    throw new ConfigDocumentError("Configuration root must be a mapping", [
      "Configuration root must be a mapping"
    ]);
  }
  const value = doc.toJS({ mapAsMap: false });
  if (!isObject(value)) {
    throw new ConfigDocumentError("Configuration root must be a mapping", [
      "Configuration root must be a mapping"
    ]);
  }
  return value;
}
function openDocument(yaml) {
  const normalizedYaml = yaml.trim() ? yaml : "{}\n";
  const data = parseYaml(normalizedYaml);
  return {
    data,
    yaml: normalizedYaml,
    revision: hashConfigValue(data),
    diagnostics: validateDocument(data)
  };
}
function getAtPath(root, path) {
  let current = root;
  for (const segment of path) {
    if (current === void 0 || !isObject(current)) return void 0;
    current = current[segment];
    if (current === void 0) return void 0;
  }
  return current;
}
function ensureParent(root, path) {
  let current = root;
  for (const segment of path.slice(0, -1)) {
    const next = current[segment];
    if (next === void 0) {
      const created = {};
      current[segment] = created;
      current = created;
    } else if (isObject(next)) {
      current = next;
    } else {
      return null;
    }
  }
  return current;
}
function valuesEqual(a, b) {
  return canonical(a) === canonical(b);
}
function namedArrayDiff(section, key, before, after) {
  const beforeById = /* @__PURE__ */ new Map();
  const afterById = /* @__PURE__ */ new Map();
  for (const value of before) {
    if (!isObject(value) || typeof value[key] !== "string") return null;
    const id = String(value[key]);
    if (beforeById.has(id)) return null;
    beforeById.set(id, value);
  }
  for (const value of after) {
    if (!isObject(value) || typeof value[key] !== "string") return null;
    const id = String(value[key]);
    if (afterById.has(id)) return null;
    afterById.set(id, value);
  }
  const operations = [];
  for (const [id, previous] of beforeById) {
    const next = afterById.get(id);
    if (!next) {
      operations.push({
        op: "delete",
        target: { path: [section], key, id },
        expectedHash: hashConfigValue(previous)
      });
    } else if (!valuesEqual(previous, next)) {
      operations.push({
        op: "upsert",
        target: { path: [section], key, id },
        expectedHash: hashConfigValue(previous),
        value: clone(next)
      });
    }
  }
  for (const [id, next] of afterById) {
    if (beforeById.has(id)) continue;
    operations.push({
      op: "upsert",
      target: { path: [section], key, id },
      expectedHash: hashConfigValue(void 0),
      value: clone(next)
    });
  }
  const beforeOrder = before.map(
    (value) => String(value[key])
  );
  const afterOrder = after.map((value) => String(value[key]));
  if (!valuesEqual(beforeOrder, afterOrder)) {
    operations.push({
      op: "order",
      target: { path: [section], key },
      expectedHash: hashConfigValue(
        beforeOrder.filter((id) => afterById.has(id))
      ),
      previousIds: beforeOrder.filter((id) => afterById.has(id)),
      ids: afterOrder
    });
  }
  return operations;
}
function namedMapDiff(section, before, after) {
  const operations = [];
  for (const [id, previous] of Object.entries(before)) {
    const next = after[id];
    if (next === void 0) {
      operations.push({
        op: "remove",
        target: { path: [section, id] },
        expectedHash: hashConfigValue(previous)
      });
    } else if (!valuesEqual(previous, next)) {
      operations.push({
        op: "set",
        target: { path: [section, id] },
        expectedHash: hashConfigValue(previous),
        value: clone(next)
      });
    }
  }
  for (const [id, next] of Object.entries(after)) {
    if (before[id] !== void 0) continue;
    operations.push({
      op: "set",
      target: { path: [section, id] },
      expectedHash: hashConfigValue(void 0),
      value: clone(next)
    });
  }
  return operations;
}
function sequenceEntries(values) {
  const occurrences = /* @__PURE__ */ new Map();
  return values.map((value) => {
    var _a;
    const hash = hashConfigValue(value);
    const occurrence = (_a = occurrences.get(hash)) != null ? _a : 0;
    occurrences.set(hash, occurrence + 1);
    return { id: `${hash}:${occurrence}`, hash, value };
  });
}
function sequenceDiff(section, before, after) {
  var _a;
  const previous = sequenceEntries(before);
  const next = sequenceEntries(after);
  const previousById = new Map(previous.map((entry) => [entry.id, entry]));
  const nextById = new Map(next.map((entry) => [entry.id, entry]));
  const operations = [];
  const consumedPrevious = /* @__PURE__ */ new Set();
  const consumedNext = /* @__PURE__ */ new Set();
  for (let index = 0; index < Math.min(previous.length, next.length); index++) {
    const oldEntry = previous[index];
    const newEntry = next[index];
    if (oldEntry.id === newEntry.id) continue;
    if (!nextById.has(oldEntry.id) && !previousById.has(newEntry.id)) {
      operations.push({
        op: "sequence-replace",
        target: { path: [section], id: oldEntry.id },
        expectedHash: oldEntry.hash,
        value: clone(newEntry.value)
      });
      consumedPrevious.add(oldEntry.id);
      consumedNext.add(newEntry.id);
    }
  }
  for (const entry of previous) {
    if (consumedPrevious.has(entry.id) || nextById.has(entry.id)) continue;
    operations.push({
      op: "sequence-delete",
      target: { path: [section], id: entry.id },
      expectedHash: entry.hash
    });
  }
  for (let index = 0; index < next.length; index++) {
    const entry = next[index];
    if (consumedNext.has(entry.id) || previousById.has(entry.id)) continue;
    const beforeId = (_a = next.slice(index + 1).find((candidate) => previousById.has(candidate.id))) == null ? void 0 : _a.id;
    operations.push({
      op: "sequence-insert",
      target: { path: [section], id: entry.id },
      expectedHash: hashConfigValue(void 0),
      value: clone(entry.value),
      ...beforeId ? { beforeId } : {}
    });
  }
  const retainedPrevious = previous.filter(
    (entry) => nextById.has(entry.id) && !consumedPrevious.has(entry.id)
  ).map((entry) => entry.id);
  const retainedNext = next.filter(
    (entry) => previousById.has(entry.id) && !consumedNext.has(entry.id)
  ).map((entry) => entry.id);
  if (!valuesEqual(retainedPrevious, retainedNext)) {
    operations.push({
      op: "sequence-order",
      target: { path: [section] },
      expectedHash: hashConfigValue(retainedPrevious),
      previousIds: retainedPrevious,
      ids: retainedNext
    });
  }
  return operations;
}
function diffDocument(base, draft) {
  const before = typeof base === "string" ? openDocument(base) : base;
  const after = typeof draft === "string" ? openDocument(draft) : draft;
  const operations = [];
  const keys = /* @__PURE__ */ new Set([
    ...Object.keys(before.data),
    ...Object.keys(after.data)
  ]);
  for (const key of keys) {
    const previous = before.data[key];
    const next = after.data[key];
    if (valuesEqual(previous, next)) continue;
    const semanticKey = NAMED_ARRAYS[key];
    if (semanticKey && Array.isArray(previous) && Array.isArray(next)) {
      const semantic = namedArrayDiff(key, semanticKey, previous, next);
      if (semantic) {
        operations.push(...semantic);
        continue;
      }
    }
    if (NAMED_MAPS.has(key) && isObject(previous) && isObject(next)) {
      operations.push(...namedMapDiff(key, previous, next));
      continue;
    }
    if (key === "rules" && Array.isArray(previous) && Array.isArray(next)) {
      operations.push(...sequenceDiff(key, previous, next));
      continue;
    }
    if (next === void 0) {
      operations.push({
        op: "remove",
        target: { path: [key] },
        expectedHash: hashConfigValue(previous)
      });
    } else {
      operations.push({
        op: "set",
        target: { path: [key] },
        expectedHash: hashConfigValue(previous),
        value: clone(next)
      });
    }
  }
  return { version: 1, baseRevision: before.revision, operations };
}
function conflict(operation, reason, current) {
  return { operation, path: operation.target.path, reason, current };
}
function applyNamedOperation(root, operation) {
  const collection = getAtPath(root, operation.target.path);
  if (!Array.isArray(collection)) {
    if (operation.op === "upsert" && operation.expectedHash === hashConfigValue(void 0)) {
      const parent = ensureParent(root, operation.target.path);
      const field = operation.target.path.at(-1);
      if (!parent || !field) return conflict(operation, "invalid-target");
      parent[field] = [clone(operation.value)];
      return;
    }
    return conflict(operation, "invalid-target", collection);
  }
  const matches = collection.map((value, index) => ({ value, index })).filter(
    ({ value }) => isObject(value) && String(value[operation.target.key]) === operation.target.id
  );
  if (matches.length > 1) return conflict(operation, "duplicate");
  const match = matches[0];
  if (!match) {
    if (operation.op === "upsert" && operation.expectedHash === hashConfigValue(void 0)) {
      collection.push(clone(operation.value));
      return;
    }
    return conflict(operation, "missing");
  }
  if (hashConfigValue(match.value) !== operation.expectedHash) {
    return conflict(operation, "changed", match.value);
  }
  if (operation.op === "delete") collection.splice(match.index, 1);
  else collection[match.index] = clone(operation.value);
}
function applyOrderOperation(root, operation) {
  const collection = getAtPath(root, operation.target.path);
  if (!Array.isArray(collection) || !operation.target.key) {
    return conflict(operation, "invalid-target", collection);
  }
  const keyed = /* @__PURE__ */ new Map();
  for (const value of collection) {
    if (!isObject(value) || typeof value[operation.target.key] !== "string") {
      return conflict(operation, "invalid-target", collection);
    }
    const id = String(value[operation.target.key]);
    if (keyed.has(id)) return conflict(operation, "duplicate");
    keyed.set(id, value);
  }
  const currentOrder = [...keyed.keys()].filter(
    (id) => operation.previousIds.includes(id)
  );
  if (operation.previousIds.some((id) => !keyed.has(id))) {
    return conflict(operation, "missing", currentOrder);
  }
  if (hashConfigValue(currentOrder) !== operation.expectedHash) {
    return conflict(operation, "changed", currentOrder);
  }
  const ordered = operation.ids.map((id) => keyed.get(id)).filter((v) => v !== void 0);
  const unknown = collection.filter((value) => {
    const id = String(value[operation.target.key]);
    return !operation.ids.includes(id);
  });
  collection.splice(0, collection.length, ...ordered, ...unknown);
}
function applySequenceOperation(root, operation) {
  const collection = getAtPath(root, operation.target.path);
  if (!Array.isArray(collection)) {
    return conflict(operation, "invalid-target", collection);
  }
  const entries = sequenceEntries(collection);
  if (operation.op === "sequence-order") {
    const byId = new Map(entries.map((entry) => [entry.id, entry.value]));
    if (operation.previousIds.some((id) => !byId.has(id))) {
      return conflict(
        operation,
        "missing",
        entries.map((entry) => entry.id)
      );
    }
    const currentOrder = entries.map((entry) => entry.id).filter((id) => operation.previousIds.includes(id));
    if (hashConfigValue(currentOrder) !== operation.expectedHash) {
      return conflict(operation, "changed", currentOrder);
    }
    const ordered = operation.ids.map((id) => byId.get(id)).filter((value) => value !== void 0);
    const unknown = entries.filter((entry) => !operation.ids.includes(entry.id)).map((entry) => entry.value);
    collection.splice(0, collection.length, ...ordered, ...unknown);
    return;
  }
  const index = entries.findIndex((entry) => entry.id === operation.target.id);
  if (operation.op === "sequence-insert") {
    if (index >= 0) return conflict(operation, "duplicate", collection[index]);
    let targetIndex = collection.length;
    if (operation.beforeId) {
      targetIndex = entries.findIndex(
        (entry) => entry.id === operation.beforeId
      );
      if (targetIndex < 0) return conflict(operation, "missing");
    }
    collection.splice(targetIndex, 0, clone(operation.value));
    return;
  }
  if (index < 0) return conflict(operation, "missing");
  if (entries[index].hash !== operation.expectedHash) {
    return conflict(operation, "changed", collection[index]);
  }
  if (operation.op === "sequence-delete") collection.splice(index, 1);
  else collection[index] = clone(operation.value);
}
function isSequenceOperation(operation) {
  return operation.op.startsWith("sequence-");
}
function stringifyTouched(sourceYaml, data, touched) {
  const doc = parseDocument(sourceYaml, {
    prettyErrors: true,
    uniqueKeys: true
  });
  if (!isMap(doc.contents)) return sourceYaml;
  for (const key of touched) {
    if (data[key] === void 0) doc.delete(key);
    else doc.set(key, doc.createNode(data[key]));
  }
  return String(doc);
}
function applyPatch(current, patch) {
  if (patch.version !== 1) {
    throw new Error(
      `Unsupported configuration patch version: ${String(patch.version)}`
    );
  }
  const source = typeof current === "string" ? openDocument(current) : current;
  const data = clone(source.data);
  const conflicts = [];
  const touched = /* @__PURE__ */ new Set();
  let applied = 0;
  for (const operation of patch.operations) {
    const top = operation.target.path[0];
    if (top) touched.add(top);
    let opConflict;
    if (operation.op === "upsert" || operation.op === "delete") {
      opConflict = applyNamedOperation(data, operation);
    } else if (operation.op === "order") {
      opConflict = applyOrderOperation(data, operation);
    } else if (isSequenceOperation(operation)) {
      opConflict = applySequenceOperation(data, operation);
    } else {
      const parent = ensureParent(data, operation.target.path);
      const field = operation.target.path.at(-1);
      if (!parent || !field) {
        opConflict = conflict(operation, "invalid-target");
      } else {
        const currentValue = getAtPath(data, operation.target.path);
        if (hashConfigValue(currentValue) !== operation.expectedHash) {
          opConflict = conflict(operation, "changed", currentValue);
        } else if (operation.op === "remove") {
          delete parent[field];
        } else {
          parent[field] = clone(operation.value);
        }
      }
    }
    if (opConflict) conflicts.push(opConflict);
    else applied++;
  }
  const yaml = stringifyTouched(source.yaml, data, touched);
  return { document: openDocument(yaml), conflicts, applied };
}
function resourceNames(data) {
  const names = /* @__PURE__ */ new Set([
    "DIRECT",
    "REJECT",
    "REJECT-DROP",
    "REJECT-TINYGIF",
    "PASS",
    "COMPATIBLE",
    "GLOBAL"
  ]);
  for (const section of ["proxies", "proxy-groups"]) {
    const entries = data[section];
    if (!Array.isArray(entries)) continue;
    for (const entry of entries) {
      if (isObject(entry) && typeof entry.name === "string")
        names.add(entry.name);
    }
  }
  return names;
}
function mapNames(data, section) {
  const value = data[section];
  return isObject(value) ? new Set(Object.keys(value)) : /* @__PURE__ */ new Set();
}
function splitRuleFields(rule) {
  const fields = [];
  let field = "";
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (const character of rule) {
    if (escaped) {
      field += character;
      escaped = false;
      continue;
    }
    if (character === "\\") {
      field += character;
      escaped = true;
      continue;
    }
    if (quote) {
      field += character;
      if (character === quote) quote = null;
      continue;
    }
    if (character === '"' || character === "'") {
      quote = character;
      field += character;
      continue;
    }
    if (character === "(" || character === "[" || character === "{") {
      depth++;
      field += character;
      continue;
    }
    if (character === ")" || character === "]" || character === "}") {
      depth = Math.max(0, depth - 1);
      field += character;
      continue;
    }
    if (character === "," && depth === 0) {
      fields.push(field.trim());
      field = "";
      continue;
    }
    field += character;
  }
  fields.push(field.trim());
  return fields;
}
function rulePolicy(rule) {
  var _a;
  const fields = splitRuleFields(rule);
  const type = (_a = fields[0]) == null ? void 0 : _a.toUpperCase();
  if (type === "MATCH") return fields[1];
  if (type === "SUB-RULE") return void 0;
  return fields[2];
}
function collectRuleReferences(rules, path) {
  if (!Array.isArray(rules)) return [];
  return rules.flatMap((rule, index) => {
    if (typeof rule !== "string") return [];
    const policy = rulePolicy(rule);
    return policy ? [{ path: [...path, index], kind: "rule-policy", name: policy }] : [];
  });
}
function collectKeyReferences(value, path, key, kind) {
  if (Array.isArray(value)) {
    return value.flatMap(
      (item, index) => collectKeyReferences(item, [...path, index], key, kind)
    );
  }
  if (!isObject(value)) return [];
  const references = [];
  for (const [field, child] of Object.entries(value)) {
    const childPath = [...path, field];
    if (field === key && typeof child === "string") {
      references.push({ path: childPath, kind, name: child });
    }
    references.push(...collectKeyReferences(child, childPath, key, kind));
  }
  return references;
}
function listResourceReferences(data) {
  const references = [];
  const groups = data["proxy-groups"];
  if (Array.isArray(groups)) {
    groups.forEach((group, groupIndex) => {
      if (!isObject(group) || !Array.isArray(group.proxies)) return;
      group.proxies.forEach((name, memberIndex) => {
        if (typeof name !== "string") return;
        references.push({
          path: ["proxy-groups", groupIndex, "proxies", memberIndex],
          kind: "proxy-group-member",
          name
        });
      });
    });
  }
  references.push(...collectRuleReferences(data.rules, ["rules"]));
  const subRules = data["sub-rules"];
  if (isObject(subRules)) {
    for (const [name, rules] of Object.entries(subRules)) {
      references.push(...collectRuleReferences(rules, ["sub-rules", name]));
    }
  }
  references.push(
    ...collectKeyReferences(data, [], "dialer-proxy", "dialer-proxy")
  );
  for (const section of ["proxy-providers", "rule-providers"]) {
    references.push(
      ...collectKeyReferences(
        data[section],
        [section],
        "proxy",
        "provider-proxy"
      )
    );
  }
  references.push(
    ...collectKeyReferences(
      data.listeners,
      ["listeners"],
      "proxy",
      "listener-proxy"
    ),
    ...collectKeyReferences(data.tunnels, ["tunnels"], "proxy", "tunnel-proxy")
  );
  return references;
}
function validateDocument(data) {
  const diagnostics = [];
  const names = resourceNames(data);
  const proxyProviders = mapNames(data, "proxy-providers");
  const ruleProviders = mapNames(data, "rule-providers");
  for (const [section, identity] of Object.entries(NAMED_ARRAYS)) {
    const entries = data[section];
    if (!Array.isArray(entries)) continue;
    const seen = /* @__PURE__ */ new Set();
    entries.forEach((entry, index) => {
      if (!isObject(entry) || typeof entry[identity] !== "string" || !entry[identity]) {
        diagnostics.push({
          path: [section, index, identity],
          code: "missing-name",
          message: `${section} entry requires ${identity}`,
          severity: "error"
        });
        return;
      }
      const id = String(entry[identity]);
      if (seen.has(id)) {
        diagnostics.push({
          path: [section, index, identity],
          code: "duplicate-name",
          message: `Duplicate ${section} identity: ${id}`,
          severity: "error"
        });
      }
      seen.add(id);
      if (["proxies", "proxy-groups", "listeners"].includes(section) && typeof entry.type !== "string") {
        diagnostics.push({
          path: [section, index, "type"],
          code: "missing-type",
          message: `${section} entry requires type`,
          severity: "error"
        });
      }
      if (section === "proxy-groups") {
        const providers = entry.use;
        if (Array.isArray(providers)) {
          providers.forEach((reference, refIndex) => {
            if (typeof reference === "string" && !proxyProviders.has(reference)) {
              diagnostics.push({
                path: [section, index, "use", refIndex],
                code: "missing-reference",
                message: `Unknown proxy provider: ${reference}`,
                severity: "error"
              });
            }
          });
        }
      }
    });
  }
  for (const reference of listResourceReferences(data)) {
    if (names.has(reference.name)) continue;
    diagnostics.push({
      path: reference.path,
      code: "missing-reference",
      message: `Unknown proxy or group: ${reference.name}`,
      // Composite rules are parsed at top-level only. Keep their policy
      // diagnostics advisory and let Mihomo's validator remain authoritative.
      severity: reference.kind === "rule-policy" ? "warning" : "error"
    });
  }
  const ruleCollections = [{ path: ["rules"], rules: data.rules }];
  const subRules = data["sub-rules"];
  if (isObject(subRules)) {
    for (const [name, rules] of Object.entries(subRules)) {
      ruleCollections.push({ path: ["sub-rules", name], rules });
    }
  }
  for (const collection of ruleCollections) {
    if (!Array.isArray(collection.rules)) continue;
    collection.rules.forEach((rule, index) => {
      var _a;
      if (typeof rule !== "string" || !rule.includes(",")) {
        diagnostics.push({
          path: [...collection.path, index],
          code: "invalid-rule",
          message: "Rule must be a comma-separated string",
          severity: "error"
        });
        return;
      }
      const parts = splitRuleFields(rule);
      if (parts[0] === "RULE-SET" && parts[1] && !ruleProviders.has(parts[1])) {
        diagnostics.push({
          path: [...collection.path, index],
          code: "missing-reference",
          message: `Unknown rule provider: ${parts[1]}`,
          severity: "error"
        });
      }
      if (((_a = parts[0]) == null ? void 0 : _a.toUpperCase()) === "SUB-RULE" && parts[2] && (!isObject(subRules) || !(parts[2] in subRules))) {
        diagnostics.push({
          path: [...collection.path, index],
          code: "missing-reference",
          message: `Unknown sub-rule: ${parts[2]}`,
          severity: "error"
        });
      }
    });
  }
  return diagnostics;
}

var __defProp$3 = Object.defineProperty;
var __defNormalProp$3 = (obj, key, value) => key in obj ? __defProp$3(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$3 = (obj, key, value) => __defNormalProp$3(obj, key + "" , value);
const VISUAL_PATCH_KEY = "x-metacubexd-visual-patch";
class ConfigPatchConflictError extends Error {
  constructor(conflicts) {
    super("visual editor patch conflicts with the base profile");
    __publicField$3(this, "conflicts", conflicts);
    this.name = "ConfigPatchConflictError";
  }
}
function visualPatchContent(patch) {
  return stringify$1({ [VISUAL_PATCH_KEY]: patch });
}
function parseVisualPatch(content) {
  const parsed = parse(content);
  if (!isPlainObject(parsed)) return void 0;
  const patch = parsed[VISUAL_PATCH_KEY];
  if (!isPlainObject(patch) || patch.version !== 1) return void 0;
  return patch;
}
const DIRECTIVES = {
  "prepend-rules": { target: "rules", at: "prepend" },
  "append-rules": { target: "rules", at: "append" },
  "prepend-proxies": { target: "proxies", at: "prepend" },
  "append-proxies": { target: "proxies", at: "append" },
  "prepend-proxy-groups": { target: "proxy-groups", at: "prepend" },
  "append-proxy-groups": { target: "proxy-groups", at: "append" }
};
function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asArray(value) {
  return Array.isArray(value) ? value : [];
}
function mergeOne(acc, overlay) {
  for (const [key, value] of Object.entries(overlay)) {
    const directive = DIRECTIVES[key];
    if (directive) {
      const baseArr = asArray(acc[directive.target]);
      const extra = asArray(value);
      acc[directive.target] = directive.at === "prepend" ? [...extra, ...baseArr] : [...baseArr, ...extra];
      continue;
    }
    const existing = acc[key];
    if (isPlainObject(existing) && isPlainObject(value)) {
      mergeOne(existing, value);
    } else {
      acc[key] = value;
    }
  }
}
function mergeConfigs(base, overlays) {
  const parsedBase = parse(base);
  if (!isPlainObject(parsedBase)) {
    throw new Error("mergeConfigs: base config must be a YAML mapping");
  }
  let acc = parsedBase;
  overlays.forEach((overlay, i) => {
    const parsed = parse(overlay);
    if (!isPlainObject(parsed)) {
      throw new Error(`mergeConfigs: overlay #${i} must be a YAML mapping`);
    }
    const visualPatch = parsed[VISUAL_PATCH_KEY];
    const ordinary = Object.fromEntries(
      Object.entries(parsed).filter(([key]) => key !== VISUAL_PATCH_KEY)
    );
    mergeOne(acc, ordinary);
    if (visualPatch !== void 0) {
      if (!isPlainObject(visualPatch) || visualPatch.version !== 1) {
        throw new Error(
          `mergeConfigs: overlay #${i} has an invalid visual patch`
        );
      }
      const result = applyPatch(
        stringify$1(acc),
        visualPatch
      );
      if (result.conflicts.length) {
        throw new ConfigPatchConflictError(result.conflicts);
      }
      acc = result.document.data;
    }
  });
  return stringify$1(acc);
}

var __defProp$2 = Object.defineProperty;
var __defNormalProp$2 = (obj, key, value) => key in obj ? __defProp$2(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$2 = (obj, key, value) => __defNormalProp$2(obj, typeof key !== "symbol" ? key + "" : key, value);
class ProfileEditorConflictError extends Error {
  constructor(conflicts) {
    super("profile editor changes conflict with the current profile");
    __publicField$2(this, "conflicts", conflicts);
    this.name = "ProfileEditorConflictError";
  }
}
class ProfileEditorValidationError extends Error {
  constructor(diagnostics, validatorMessage) {
    super(validatorMessage || "profile editor validation failed");
    __publicField$2(this, "diagnostics", diagnostics);
    __publicField$2(this, "validatorMessage", validatorMessage);
    this.name = "ProfileEditorValidationError";
  }
}
const SCHEMA_VERSION = "meta-json-schema@1.19.28";
function managedOverlay(list, baseId) {
  return list.find(
    (meta) => meta.type === "merge" && meta.baseProfileId === baseId && meta.managedBy === "visual-editor"
  );
}
function createProfileConfigEditor(options) {
  const { profiles, supervisor, homeDir } = options;
  async function findProfile(id) {
    const meta = (await profiles.list()).find((item) => item.id === id);
    if (!meta) throw new Error(`profile not found: ${id}`);
    if (meta.type === "merge" || meta.type === "script") {
      throw new Error("visual editor only supports base profiles");
    }
    return meta;
  }
  async function editableState(id) {
    const list = await profiles.list();
    const profile = list.find((item) => item.id === id);
    if (!profile) throw new Error(`profile not found: ${id}`);
    if (profile.type === "merge" || profile.type === "script") {
      throw new Error("visual editor only supports base profiles");
    }
    const baseYaml = await profiles.read(id);
    const baseDocument = openDocument(baseYaml);
    const overlay = managedOverlay(list, id);
    const storedPatch = overlay ? parseVisualPatch(await profiles.read(overlay.id)) : void 0;
    const patched = storedPatch ? applyPatch(baseDocument, storedPatch) : { document: baseDocument, conflicts: []};
    return {
      list,
      profile,
      baseDocument,
      overlay,
      editableDocument: patched.document,
      conflicts: patched.conflicts
    };
  }
  async function composeForDraft(id, profile, editableYaml) {
    if (profile.type === "remote") {
      const baseYaml = await profiles.read(id);
      const cumulative = diffDocument(baseYaml, editableYaml);
      const managedContent = visualPatchContent(cumulative);
      const composed2 = await profiles.compose(id, {
        managedOverlayContent: managedContent
      });
      return { ...composed2, cumulative };
    }
    const composed = await profiles.compose(id, {
      profileContent: editableYaml
    });
    return {
      ...composed,
      cumulative: diffDocument(await profiles.read(id), editableYaml)
    };
  }
  async function open(id) {
    const state = await editableState(id);
    let composedYaml = state.editableDocument.yaml;
    let composition = [];
    try {
      const composed = await composeForDraft(
        id,
        state.profile,
        state.editableDocument.yaml
      );
      composedYaml = composed.content;
      composition = composed.composition;
    } catch (error) {
      if (!(error instanceof ConfigPatchConflictError)) throw error;
    }
    return {
      profile: state.profile,
      active: await profiles.getActiveId() === id,
      revision: state.editableDocument.revision,
      editableYaml: state.editableDocument.yaml,
      composedYaml,
      schemaVersion: SCHEMA_VERSION,
      composition,
      diagnostics: state.editableDocument.diagnostics,
      conflicts: state.conflicts
    };
  }
  async function preview(id, patch) {
    const state = await editableState(id);
    const applied = applyPatch(state.editableDocument, patch);
    const conflicts = applied.conflicts;
    const composed = await composeForDraft(
      id,
      state.profile,
      applied.document.yaml
    );
    return {
      profile: state.profile,
      active: await profiles.getActiveId() === id,
      revision: applied.document.revision,
      editableYaml: applied.document.yaml,
      composedYaml: composed.content,
      schemaVersion: SCHEMA_VERSION,
      composition: composed.composition,
      diagnostics: applied.document.diagnostics,
      conflicts,
      patch: composed.cumulative
    };
  }
  async function apply(id, patch) {
    var _a, _b;
    const before = await editableState(id);
    const result = await preview(id, patch);
    if (result.conflicts.length) {
      throw new ProfileEditorConflictError(result.conflicts);
    }
    const errors = result.diagnostics.filter(
      (diagnostic) => diagnostic.severity === "error"
    );
    if (errors.length) throw new ProfileEditorValidationError(errors);
    const candidate = join(
      homeDir,
      `.editor-${id}-${Date.now().toString(36)}.yaml`
    );
    await writeFile$1(candidate, result.composedYaml);
    try {
      const validation = await supervisor.validate(candidate);
      if (!validation.valid) {
        throw new ProfileEditorValidationError([], validation.message);
      }
    } finally {
      await rm(candidate, { force: true });
    }
    const previousActiveId = await profiles.getActiveId();
    const originalProfileContent = await profiles.read(id);
    const originalOverlayContent = before.overlay ? await profiles.read(before.overlay.id) : void 0;
    let createdOverlayId;
    try {
      if (before.profile.type === "remote") {
        const content = visualPatchContent(result.patch);
        if (before.overlay) {
          await profiles.update(before.overlay.id, {
            content,
            editorStatus: "clean"
          });
        } else {
          const created = await profiles.create({
            name: `${before.profile.name} \xB7 Visual overrides`,
            type: "merge",
            content,
            baseProfileId: id,
            managedBy: "visual-editor",
            editorStatus: "clean"
          });
          createdOverlayId = created.id;
        }
        await profiles.update(id, { editorStatus: "clean" });
      } else {
        await profiles.update(id, { content: result.editableYaml });
      }
      await profiles.setActive(id);
      const kernel = await supervisor.restart();
      const profile = await findProfile(id);
      return {
        profile,
        activeId: id,
        revision: result.revision,
        kernel
      };
    } catch (error) {
      if (before.profile.type === "remote") {
        if (before.overlay && originalOverlayContent !== void 0) {
          await profiles.update(before.overlay.id, {
            content: originalOverlayContent,
            editorStatus: (_a = before.overlay.editorStatus) != null ? _a : null
          }).catch(() => {
          });
        } else if (createdOverlayId) {
          await profiles.delete(createdOverlayId).catch(() => {
          });
        }
      } else {
        await profiles.update(id, { content: originalProfileContent }).catch(() => {
        });
      }
      await profiles.update(id, { editorStatus: (_b = before.profile.editorStatus) != null ? _b : null }).catch(() => {
      });
      if (previousActiveId) {
        await profiles.setActive(previousActiveId).catch(() => {
        });
        await supervisor.restart().catch(() => {
        });
      } else {
        await profiles.resetActive().catch(() => {
        });
        await supervisor.restart().catch(() => {
        });
      }
      throw error;
    }
  }
  async function resetManagedOverlay(id) {
    var _a;
    const list = await profiles.list();
    const overlay = managedOverlay(list, id);
    if (!overlay) return void 0;
    const base = list.find((meta) => meta.id === id);
    if (!base) throw new Error(`profile not found: ${id}`);
    const active = await profiles.getActiveId() === id;
    const overlayContent = await profiles.read(overlay.id);
    const emptyPatch = {
      version: 1,
      baseRevision: "",
      operations: []
    };
    const candidate = await profiles.compose(id, {
      managedOverlayContent: visualPatchContent(emptyPatch)
    });
    const candidatePath = join(
      homeDir,
      `.editor-reset-${id}-${Date.now().toString(36)}.yaml`
    );
    await writeFile$1(candidatePath, candidate.content);
    try {
      const validation = await supervisor.validate(candidatePath);
      if (!validation.valid) {
        throw new ProfileEditorValidationError([], validation.message);
      }
    } finally {
      await rm(candidatePath, { force: true });
    }
    await profiles.delete(overlay.id);
    try {
      if (!active) return void 0;
      await profiles.setActive(id);
      return await supervisor.restart();
    } catch (error) {
      await profiles.create({
        name: overlay.name,
        type: "merge",
        content: overlayContent,
        baseProfileId: id,
        managedBy: "visual-editor",
        editorStatus: overlay.editorStatus
      }).catch(() => {
      });
      await profiles.update(id, { editorStatus: (_a = base.editorStatus) != null ? _a : null }).catch(() => {
      });
      if (active) {
        await profiles.setActive(id).catch(() => {
        });
        await supervisor.restart().catch(() => {
        });
      }
      throw error;
    }
  }
  return { open, preview, apply, resetManagedOverlay };
}

var __defProp$1 = Object.defineProperty;
var __defNormalProp$1 = (obj, key, value) => key in obj ? __defProp$1(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$1 = (obj, key, value) => __defNormalProp$1(obj, key + "" , value);
class SubscriptionFetchError extends Error {
  constructor(upstreamStatus) {
    super(`subscription provider returned HTTP ${upstreamStatus}`);
    __publicField$1(this, "upstreamStatus", upstreamStatus);
    this.name = "SubscriptionFetchError";
  }
}
function createProfileStore(opts) {
  var _a, _b, _c;
  const { dir, activeConfigPath, scriptRunner } = opts;
  const doFetch = (_a = opts.fetch) != null ? _a : fetch;
  const subscriptionTimeoutMs = (_b = opts.subscriptionTimeoutMs) != null ? _b : 3e4;
  const idGen = (_c = opts.idGen) != null ? _c : (() => randomUUID());
  const indexPath = join(dir, "index.json");
  const statePath = join(dir, "state.json");
  const profilePath = (id) => join(dir, `${id}.yaml`);
  async function ensureDir() {
    await mkdir(dir, { recursive: true });
  }
  async function atomicWrite(path, content) {
    const temporary = `${path}.${randomUUID()}.tmp`;
    await writeFile$1(temporary, content);
    try {
      await rename(temporary, path);
    } finally {
      await rm(temporary, { force: true });
    }
  }
  async function readIndex() {
    if (!existsSync(indexPath)) return [];
    return JSON.parse(await readFile$1(indexPath, "utf8"));
  }
  async function writeIndex(list) {
    await ensureDir();
    await atomicWrite(indexPath, `${JSON.stringify(list, null, 2)}
`);
  }
  async function readState() {
    if (!existsSync(statePath)) return {};
    return JSON.parse(await readFile$1(statePath, "utf8"));
  }
  async function writeState(s) {
    await ensureDir();
    await atomicWrite(statePath, `${JSON.stringify(s, null, 2)}
`);
  }
  async function findMeta(id) {
    const meta = (await readIndex()).find((m) => m.id === id);
    if (!meta) throw new Error(`profile not found: ${id}`);
    return meta;
  }
  function parseSubscriptionUserinfo(header) {
    var _a2, _b2, _c2, _d;
    if (!header) return void 0;
    const out = {};
    for (const part of header.split(";")) {
      const [k, v] = part.split("=").map((s) => s.trim());
      if (k && v != null && !Number.isNaN(Number(v))) out[k] = Number(v);
    }
    if (!("upload" in out) && !("download" in out) && !("total" in out)) {
      return void 0;
    }
    return {
      upload: (_a2 = out.upload) != null ? _a2 : 0,
      download: (_b2 = out.download) != null ? _b2 : 0,
      total: (_c2 = out.total) != null ? _c2 : 0,
      expire: (_d = out.expire) != null ? _d : 0
    };
  }
  async function fetchSubscription(url, userAgent) {
    const signal = AbortSignal.timeout(subscriptionTimeoutMs);
    try {
      const res = await doFetch(url, {
        headers: { "User-Agent": userAgent },
        signal
      });
      if (!res.ok) {
        throw new SubscriptionFetchError(res.status);
      }
      const content = await res.text();
      const subscriptionInfo = parseSubscriptionUserinfo(
        res.headers.get("subscription-userinfo")
      );
      return { content, subscriptionInfo };
    } catch (err) {
      if (signal.aborted) {
        throw new Error(
          `subscription fetch timed out after ${subscriptionTimeoutMs}ms for ${url}`
        );
      }
      throw err;
    }
  }
  const store = {
    async list() {
      return readIndex();
    },
    async read(id) {
      await findMeta(id);
      return readFile$1(profilePath(id), "utf8");
    },
    async create(i) {
      var _a2, _b2;
      await ensureDir();
      const current = await readIndex();
      if (i.managedBy === "visual-editor") {
        if (i.type !== "merge" || !i.baseProfileId) {
          throw new Error(
            "visual editor overlays must be scoped merge profiles"
          );
        }
        if (current.some(
          (meta2) => meta2.managedBy === "visual-editor" && meta2.baseProfileId === i.baseProfileId
        )) {
          throw new Error(
            `visual editor overlay already exists for ${i.baseProfileId}`
          );
        }
      }
      const id = idGen();
      const meta = {
        id,
        name: i.name,
        type: (_a2 = i.type) != null ? _a2 : "local",
        ...i.baseProfileId ? { baseProfileId: i.baseProfileId } : {},
        ...i.managedBy ? { managedBy: i.managedBy } : {},
        ...i.editorStatus ? { editorStatus: i.editorStatus } : {},
        updatedAt: Date.now()
      };
      await atomicWrite(profilePath(id), (_b2 = i.content) != null ? _b2 : "");
      try {
        await writeIndex([...current, meta]);
      } catch (error) {
        await rm(profilePath(id), { force: true }).catch(() => {
        });
        throw error;
      }
      return meta;
    },
    async update(id, p) {
      const list = await readIndex();
      const meta = list.find((m) => m.id === id);
      if (!meta) throw new Error(`profile not found: ${id}`);
      if (p.content != null) await atomicWrite(profilePath(id), p.content);
      if (p.name != null) meta.name = p.name;
      if (p.enabled != null) meta.enabled = p.enabled;
      if (p.updateInterval != null) meta.updateInterval = p.updateInterval;
      if (p.editorStatus === null) delete meta.editorStatus;
      else if (p.editorStatus !== void 0) meta.editorStatus = p.editorStatus;
      if (p.name != null || p.content != null || p.enabled != null || p.updateInterval != null) {
        meta.updatedAt = Date.now();
      }
      await writeIndex(list);
      return meta;
    },
    async delete(id) {
      const list = await readIndex();
      const removed = list.find((meta) => meta.id === id);
      if (!removed) throw new Error(`profile not found: ${id}`);
      const removedIds = /* @__PURE__ */ new Set([
        id,
        ...list.filter((meta) => meta.baseProfileId === id).map((meta) => meta.id)
      ]);
      await Promise.all(
        [...removedIds].map(
          (removedId) => rm(profilePath(removedId), { force: true })
        )
      );
      const retained = list.filter((m) => !removedIds.has(m.id));
      if (removed.managedBy === "visual-editor" && removed.baseProfileId) {
        const base = retained.find((meta) => meta.id === removed.baseProfileId);
        if (base) base.editorStatus = "clean";
      }
      await writeIndex(retained);
      const state = await readState();
      if (state.activeId === id) {
        delete state.activeId;
        await writeState(state);
      }
    },
    async duplicate(id, name) {
      const src = await findMeta(id);
      const content = await readFile$1(profilePath(id), "utf8");
      const newId = idGen();
      const meta = {
        id: newId,
        name: name != null ? name : `${src.name} copy`,
        type: "local",
        updatedAt: Date.now()
      };
      await atomicWrite(profilePath(newId), content);
      await writeIndex([...await readIndex(), meta]);
      return meta;
    },
    async importFromUrl(url, name) {
      await ensureDir();
      const userAgent = "clash.meta";
      const { content, subscriptionInfo } = await fetchSubscription(
        url,
        userAgent
      );
      const id = idGen();
      const meta = {
        id,
        name: name != null ? name : url,
        type: "remote",
        url,
        userAgent,
        updatedAt: Date.now(),
        ...subscriptionInfo ? { subscriptionInfo } : {}
      };
      await atomicWrite(profilePath(id), content);
      await writeIndex([...await readIndex(), meta]);
      return meta;
    },
    async refresh(id) {
      var _a2;
      const list = await readIndex();
      const meta = list.find((m) => m.id === id);
      if (!meta) throw new Error(`profile not found: ${id}`);
      if (meta.type !== "remote" || !meta.url) {
        throw new Error(`refresh: profile ${id} is not a remote subscription`);
      }
      const userAgent = (_a2 = meta.userAgent) != null ? _a2 : "clash.meta";
      const { content, subscriptionInfo } = await fetchSubscription(
        meta.url,
        userAgent
      );
      await atomicWrite(profilePath(id), content);
      meta.updatedAt = Date.now();
      if (subscriptionInfo) meta.subscriptionInfo = subscriptionInfo;
      try {
        await store.compose(id);
        meta.editorStatus = "clean";
      } catch (error) {
        if (!(error instanceof ConfigPatchConflictError)) throw error;
        meta.editorStatus = "conflicted";
      }
      await writeIndex(list);
      return meta;
    },
    async getActiveId() {
      return (await readState()).activeId;
    },
    async setActive(id) {
      const { content } = await store.compose(id);
      await mkdir(join(activeConfigPath, ".."), { recursive: true });
      if (existsSync(activeConfigPath)) {
        await copyFile(activeConfigPath, `${activeConfigPath}.bak`);
      }
      await atomicWrite(activeConfigPath, content);
      await writeState({ activeId: id });
    },
    async compose(id, overrides) {
      var _a2;
      const base = await findMeta(id);
      if (base.type === "merge" || base.type === "script") {
        throw new Error(
          `setActive: profile ${id} is a ${base.type} overlay and cannot be the active base`
        );
      }
      const baseContent = (_a2 = overrides == null ? void 0 : overrides.profileContent) != null ? _a2 : await readFile$1(profilePath(id), "utf8");
      const index = await readIndex();
      const managed = index.filter(
        (meta) => meta.managedBy === "visual-editor" && meta.baseProfileId === id
      );
      if (managed.length > 1) {
        throw new Error(`multiple visual editor overlays found for ${id}`);
      }
      const overlays = [];
      const scripts = [];
      const composition = [];
      let managedOverrideApplied = false;
      for (const meta of index) {
        if (meta.enabled === false) continue;
        if (meta.type === "merge") {
          if (meta.baseProfileId && meta.baseProfileId !== id) continue;
          const content2 = meta.managedBy === "visual-editor" && meta.baseProfileId === id && (overrides == null ? void 0 : overrides.managedOverlayContent) !== void 0 ? overrides.managedOverlayContent : await readFile$1(profilePath(meta.id), "utf8");
          if (meta.managedBy === "visual-editor" && meta.baseProfileId === id && (overrides == null ? void 0 : overrides.managedOverlayContent) !== void 0) {
            managedOverrideApplied = true;
          }
          overlays.push(content2);
          composition.push(meta);
        } else if (meta.type === "script" && scriptRunner) {
          scripts.push(await readFile$1(profilePath(meta.id), "utf8"));
          composition.push(meta);
        }
      }
      if ((overrides == null ? void 0 : overrides.managedOverlayContent) !== void 0 && !managedOverrideApplied) {
        overlays.push(overrides.managedOverlayContent);
      }
      let content = overlays.length ? mergeConfigs(baseContent, overlays) : baseContent;
      if (scripts.length && scriptRunner) {
        let obj = parse(content);
        for (const code of scripts) {
          obj = await scriptRunner.run(code, obj);
        }
        content = stringify$1(obj);
      }
      return { content, composition };
    },
    async rollback() {
      const bak = `${activeConfigPath}.bak`;
      if (!existsSync(bak)) return false;
      await mkdir(join(activeConfigPath, ".."), { recursive: true });
      await copyFile(bak, activeConfigPath);
      return true;
    },
    async resetActive() {
      await mkdir(join(activeConfigPath, ".."), { recursive: true });
      if (existsSync(activeConfigPath)) {
        await copyFile(activeConfigPath, `${activeConfigPath}.bak`);
      }
      await atomicWrite(activeConfigPath, "");
      await writeState({});
    },
    async getSection(id, key) {
      await findMeta(id);
      const parsed = parse(await readFile$1(profilePath(id), "utf8"));
      if (!isPlainObject(parsed)) return null;
      const value = parsed[key];
      return value === void 0 ? null : value;
    },
    async setSection(id, key, value) {
      await findMeta(id);
      const parsed = parse(await readFile$1(profilePath(id), "utf8"));
      const doc = isPlainObject(parsed) ? parsed : {};
      if (value == null) {
        delete doc[key];
      } else {
        doc[key] = value;
      }
      await store.update(id, { content: stringify$1(doc) });
    }
  };
  return store;
}

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, key + "" , value);
class TunPreconditionError extends Error {
  constructor(message, statusCode = 409) {
    super(message);
    __publicField(this, "statusCode");
    this.name = "TunPreconditionError";
    this.statusCode = statusCode;
  }
}

function joinUrl(base, path) {
  let baseEnd = base.length;
  while (baseEnd > 0 && base[baseEnd - 1] === "/") baseEnd--;
  let pathStart = 0;
  while (path[pathStart] === "/") pathStart++;
  return `${base.slice(0, baseEnd)}/${path.slice(pathStart)}`;
}
function createWebdavClient(opts) {
  var _a;
  const doFetch = (_a = opts.fetch) != null ? _a : fetch;
  const authorization = `Basic ${Buffer$1.from(
    `${opts.username}:${opts.password}`
  ).toString("base64")}`;
  async function request(method, path, body) {
    return doFetch(joinUrl(opts.url, path), {
      method,
      headers: { authorization },
      ...body != null ? { body } : {}
    });
  }
  return {
    async put(path, body) {
      const res = await request("PUT", path, body);
      if (!res.ok) {
        throw new Error(
          `webdav PUT failed ${res.status} ${res.statusText} for ${path}`
        );
      }
    },
    async get(path) {
      const res = await request("GET", path);
      if (!res.ok) {
        throw new Error(
          `webdav GET failed ${res.status} ${res.statusText} for ${path}`
        );
      }
      return res.text();
    },
    async mkcol(dir) {
      const res = await request("MKCOL", dir);
      if (res.ok || res.status === 405 || res.status === 301) return;
      throw new Error(
        `webdav MKCOL failed ${res.status} ${res.statusText} for ${dir}`
      );
    }
  };
}

const BACKUP_FILENAME = "metacubexd-backup.json";
async function withSubscriptionHttpError(action) {
  try {
    return await action();
  } catch (error) {
    if (error instanceof SubscriptionFetchError) {
      const message = `Subscription provider returned HTTP ${error.upstreamStatus}`;
      throw createError$1({
        statusCode: error.upstreamStatus,
        statusMessage: message,
        data: { error: message, upstreamStatus: error.upstreamStatus }
      });
    }
    throw error;
  }
}
const PREFIX = "/api/control";
function createControlRouter(deps) {
  const app = createApp();
  const router = createRouter();
  const {
    supervisor,
    profiles,
    profileEditor,
    info,
    homeDir,
    activeConfigPath,
    token,
    systemProxy,
    kernelManager,
    tunController,
    geoFetch,
    createWebdavClient: createWebdavClient$1 = createWebdavClient,
    readFile = readFile$1
  } = deps;
  function isPublic(path) {
    return path === `${PREFIX}/health` || path === `${PREFIX}/info`;
  }
  function authorized(event) {
    if (!token) return true;
    const header = getHeader(event, "authorization");
    if (header === `Bearer ${token}`) return true;
    const q = getQuery(event);
    if (q.token === token) return true;
    return false;
  }
  app.use(
    defineEventHandler((event) => {
      var _a, _b;
      const path = (_b = ((_a = event.path) != null ? _a : "").split("?")[0]) != null ? _b : "";
      if (!path.startsWith(PREFIX)) return;
      if (isPublic(path)) return;
      if (!authorized(event)) {
        setResponseStatus(event, 401);
        return { error: "unauthorized" };
      }
    })
  );
  router.get(
    `${PREFIX}/health`,
    defineEventHandler(() => ({ ok: true }))
  );
  router.get(
    `${PREFIX}/info`,
    defineEventHandler(() => info())
  );
  router.get(
    `${PREFIX}/kernel/status`,
    defineEventHandler(() => supervisor.getState())
  );
  router.post(
    `${PREFIX}/kernel/start`,
    defineEventHandler(() => supervisor.start())
  );
  router.post(
    `${PREFIX}/kernel/stop`,
    defineEventHandler(() => supervisor.stop())
  );
  router.post(
    `${PREFIX}/kernel/restart`,
    defineEventHandler(() => supervisor.restart())
  );
  router.post(
    `${PREFIX}/kernel/rollback`,
    defineEventHandler(async (event) => {
      const restored = await profiles.rollback();
      if (!restored) {
        setResponseStatus(event, 404);
        return { error: "no backup config to roll back to" };
      }
      return supervisor.restart();
    })
  );
  router.post(
    `${PREFIX}/kernel/recover`,
    defineEventHandler(async () => {
      await profiles.resetActive();
      return supervisor.restart();
    })
  );
  router.get(
    `${PREFIX}/kernel/logs`,
    defineEventHandler((event) => {
      const stream = createEventStream(event);
      const onLog = (l) => stream.push(JSON.stringify({ type: "log", ...l }));
      const onState = (s) => stream.push(JSON.stringify({ type: "state", ...s }));
      supervisor.on("log", onLog);
      supervisor.on("state", onState);
      stream.onClosed(() => {
        supervisor.off("log", onLog);
        supervisor.off("state", onState);
      });
      stream.push(JSON.stringify({ type: "state", ...supervisor.getState() }));
      return stream.send();
    })
  );
  async function safeActivate(id) {
    const previousActiveId = await profiles.getActiveId();
    try {
      await profiles.setActive(id);
    } catch (error) {
      if (error instanceof ConfigPatchConflictError) {
        throw createError$1({
          statusCode: 409,
          statusMessage: "profile editor conflict",
          data: { error: error.message, conflicts: error.conflicts }
        });
      }
      throw error;
    }
    const validation = await supervisor.validate(activeConfigPath);
    if (validation.valid) return supervisor.restart();
    if (previousActiveId && previousActiveId !== id) {
      await profiles.setActive(previousActiveId).catch(() => {
      });
    } else {
      await profiles.rollback().catch(() => {
      });
    }
    throw createError$1({
      statusCode: 400,
      statusMessage: "profile validation failed",
      data: { error: validation.message }
    });
  }
  router.get(
    `${PREFIX}/profiles`,
    defineEventHandler(async () => {
      const [list, activeId] = await Promise.all([
        profiles.list(),
        profiles.getActiveId()
      ]);
      return list.map((p) => ({ ...p, active: p.id === activeId }));
    })
  );
  router.post(
    `${PREFIX}/profiles`,
    defineEventHandler(async (event) => {
      const body = await readBody(event);
      return profiles.create(body);
    })
  );
  router.get(
    `${PREFIX}/profiles/:id`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      const [meta, content] = await Promise.all([
        profiles.list().then((l) => l.find((m) => m.id === id)),
        profiles.read(id)
      ]);
      return { meta, content };
    })
  );
  router.put(
    `${PREFIX}/profiles/:id`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      const body = await readBody(event);
      const meta = (await profiles.list()).find((item) => item.id === id);
      if ((meta == null ? void 0 : meta.managedBy) === "visual-editor") {
        throw createError$1({
          statusCode: 403,
          statusMessage: "managed visual editor overlays are read-only"
        });
      }
      return profiles.update(id, body);
    })
  );
  router.delete(
    `${PREFIX}/profiles/:id`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      await profiles.delete(id);
      return sendNoContent(event);
    })
  );
  router.post(
    `${PREFIX}/profiles/:id/duplicate`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      const body = await readBody(event).catch(() => ({}));
      return profiles.duplicate(id, body == null ? void 0 : body.name);
    })
  );
  router.post(
    `${PREFIX}/profiles/import`,
    defineEventHandler(async (event) => {
      const body = await readBody(event);
      return withSubscriptionHttpError(
        () => profiles.importFromUrl(body.url, body.name)
      );
    })
  );
  router.post(
    `${PREFIX}/profiles/:id/refresh`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      return withSubscriptionHttpError(() => profiles.refresh(id));
    })
  );
  router.post(
    `${PREFIX}/profiles/:id/refresh-and-activate`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      const meta = await withSubscriptionHttpError(() => profiles.refresh(id));
      const kernel = await safeActivate(id);
      return { meta, kernel };
    })
  );
  router.post(
    `${PREFIX}/profiles/:id/activate`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      return safeActivate(id);
    })
  );
  router.post(
    `${PREFIX}/profiles/:id/validate`,
    defineEventHandler(async (event) => {
      const id = getRouterParam(event, "id");
      const content = await profiles.read(id);
      const candidate = join(homeDir, `.validate-${id}.yaml`);
      await writeFile$1(candidate, content);
      try {
        return await supervisor.validate(candidate);
      } finally {
        await rm(candidate, { force: true });
      }
    })
  );
  if (profileEditor) {
    const readEditorPatch = async (event) => {
      var _a;
      const body = await readBody(event);
      if (((_a = body.patch) == null ? void 0 : _a.version) !== 1 || !Array.isArray(body.patch.operations)) {
        throw createError$1({
          statusCode: 400,
          statusMessage: "invalid visual editor patch"
        });
      }
      return body.patch;
    };
    const withEditorError = async (action) => {
      try {
        return await action();
      } catch (error) {
        if (error instanceof ProfileEditorConflictError) {
          throw createError$1({
            statusCode: 409,
            statusMessage: "profile editor conflict",
            data: { error: error.message, conflicts: error.conflicts }
          });
        }
        if (error instanceof ProfileEditorValidationError) {
          throw createError$1({
            statusCode: 400,
            statusMessage: "profile editor validation failed",
            data: {
              error: error.message,
              diagnostics: error.diagnostics,
              validatorMessage: error.validatorMessage
            }
          });
        }
        throw error;
      }
    };
    router.get(
      `${PREFIX}/profiles/:id/editor`,
      defineEventHandler((event) => {
        const id = getRouterParam(event, "id");
        return withEditorError(() => profileEditor.open(id));
      })
    );
    router.post(
      `${PREFIX}/profiles/:id/editor/preview`,
      defineEventHandler(async (event) => {
        const id = getRouterParam(event, "id");
        const patch = await readEditorPatch(event);
        return withEditorError(() => profileEditor.preview(id, patch));
      })
    );
    router.put(
      `${PREFIX}/profiles/:id/editor`,
      defineEventHandler(async (event) => {
        const id = getRouterParam(event, "id");
        const patch = await readEditorPatch(event);
        return withEditorError(() => profileEditor.apply(id, patch));
      })
    );
    router.delete(
      `${PREFIX}/profiles/:id/editor/overlay`,
      defineEventHandler(async (event) => {
        const id = getRouterParam(event, "id");
        const kernel = await withEditorError(
          () => profileEditor.resetManagedOverlay(id)
        );
        return kernel != null ? kernel : { ok: true };
      })
    );
  }
  router.get(
    `${PREFIX}/config`,
    defineEventHandler(async (event) => {
      const activeId = await profiles.getActiveId();
      setResponseHeader(event, "content-type", "text/yaml");
      return activeId ? profiles.read(activeId) : "";
    })
  );
  router.put(
    `${PREFIX}/config`,
    defineEventHandler(async (event) => {
      const activeId = await profiles.getActiveId();
      if (!activeId) {
        setResponseStatus(event, 409);
        return { error: "no active profile" };
      }
      const body = await readBody(event);
      await profiles.update(activeId, { content: body.content });
      await profiles.setActive(activeId);
      return supervisor.restart();
    })
  );
  router.get(
    `${PREFIX}/config/runtime`,
    defineEventHandler(async (event) => {
      setResponseHeader(event, "content-type", "text/yaml");
      try {
        return await readFile(activeConfigPath, "utf8");
      } catch (err) {
        if (err.code === "ENOENT") return "";
        throw err;
      }
    })
  );
  router.get(
    `${PREFIX}/config/section`,
    defineEventHandler(async (event) => {
      var _a;
      const key = String((_a = getQuery(event).key) != null ? _a : "");
      const activeId = await profiles.getActiveId();
      const value = activeId ? await profiles.getSection(activeId, key) : null;
      setResponseHeader(event, "content-type", "application/json");
      return JSON.stringify(value != null ? value : null);
    })
  );
  router.put(
    `${PREFIX}/config/section`,
    defineEventHandler(async (event) => {
      const activeId = await profiles.getActiveId();
      if (!activeId) {
        setResponseStatus(event, 409);
        return { error: "no active profile" };
      }
      const body = await readBody(event);
      await profiles.setSection(activeId, body.key, body.value);
      await profiles.setActive(activeId);
      if (body.restart === false) return supervisor.getState();
      return supervisor.restart();
    })
  );
  router.post(
    `${PREFIX}/geo/update`,
    defineEventHandler(async () => {
      const { files } = await fetchGeoAssets(homeDir, { fetch: geoFetch });
      return { ok: true, files };
    })
  );
  function backupPath(dir) {
    if (!dir) return BACKUP_FILENAME;
    let end = dir.length;
    while (end > 0 && dir[end - 1] === "/") end--;
    return `${dir.slice(0, end)}/${BACKUP_FILENAME}`;
  }
  router.post(
    `${PREFIX}/backup`,
    defineEventHandler(async (event) => {
      const body = await readBody(event);
      const { webdav } = body;
      const client = createWebdavClient$1({
        url: webdav.url,
        username: webdav.username,
        password: webdav.password
      });
      const metas = await profiles.list();
      const bundleProfiles = await Promise.all(
        metas.map(async (meta) => ({
          meta,
          content: await profiles.read(meta.id)
        }))
      );
      const bundle = {
        version: 1,
        profiles: bundleProfiles,
        ...body.uiSettings !== void 0 ? { uiSettings: body.uiSettings } : {}
      };
      if (webdav.dir) {
        await client.mkcol(webdav.dir).catch(() => {
        });
      }
      const path = backupPath(webdav.dir);
      await client.put(path, JSON.stringify(bundle));
      return { ok: true, path };
    })
  );
  router.post(
    `${PREFIX}/restore`,
    defineEventHandler(async (event) => {
      var _a, _b;
      const body = await readBody(event);
      const { webdav } = body;
      const client = createWebdavClient$1({
        url: webdav.url,
        username: webdav.username,
        password: webdav.password
      });
      const raw = await client.get(backupPath(webdav.dir));
      const bundle = JSON.parse(raw);
      let restored = 0;
      const restoredIds = /* @__PURE__ */ new Map();
      const ordinary = ((_a = bundle.profiles) != null ? _a : []).filter(
        (profile) => profile.meta.managedBy !== "visual-editor"
      );
      const managed = ((_b = bundle.profiles) != null ? _b : []).filter(
        (profile) => profile.meta.managedBy === "visual-editor"
      );
      for (const p of [...ordinary, ...managed]) {
        const type = p.meta.type === "merge" || p.meta.type === "script" ? p.meta.type : "local";
        const mappedBaseId = p.meta.baseProfileId ? restoredIds.get(p.meta.baseProfileId) : void 0;
        const created = await profiles.create({
          name: p.meta.name,
          content: p.content,
          type,
          ...mappedBaseId ? { baseProfileId: mappedBaseId } : {},
          ...p.meta.managedBy ? { managedBy: p.meta.managedBy } : {},
          ...p.meta.editorStatus ? { editorStatus: p.meta.editorStatus } : {}
        });
        if (p.meta.id) restoredIds.set(p.meta.id, created.id);
        restored += 1;
      }
      return { ok: true, restored, uiSettings: bundle.uiSettings };
    })
  );
  if (systemProxy) {
    router.get(
      `${PREFIX}/sysproxy`,
      defineEventHandler(async () => ({
        enabled: await systemProxy.isEnabled(),
        ...systemProxy.describe()
      }))
    );
    router.post(
      `${PREFIX}/sysproxy`,
      defineEventHandler(async (event) => {
        var _a;
        const body = await readBody(event);
        if (body.bypass && body.bypass.length > 0) {
          (_a = systemProxy.setDefaultBypass) == null ? void 0 : _a.call(systemProxy, body.bypass);
        }
        if (body.mode === "pac") {
          if (body.enabled) {
            if (!body.pacUrl) {
              setResponseStatus(event, 400);
              return { error: "pacUrl required for pac mode" };
            }
            await systemProxy.setAutoProxy(body.pacUrl);
          } else {
            await systemProxy.disableAutoProxy();
          }
        } else if (body.enabled) {
          await systemProxy.enable(body.bypass);
        } else {
          await systemProxy.disable();
        }
        return {
          enabled: await systemProxy.isEnabled(),
          ...systemProxy.describe()
        };
      })
    );
  } else {
    const unavailable = defineEventHandler((event) => {
      setResponseStatus(event, 404);
      return { error: "system-proxy unavailable" };
    });
    router.get(`${PREFIX}/sysproxy`, unavailable);
    router.post(`${PREFIX}/sysproxy`, unavailable);
  }
  if (kernelManager) {
    router.get(
      `${PREFIX}/kernel/versions`,
      defineEventHandler(() => kernelManager.listVersions())
    );
    router.post(
      `${PREFIX}/kernel/switch`,
      defineEventHandler(async (event) => {
        const body = await readBody(event);
        await kernelManager.switch(body.version);
        return { ok: true };
      })
    );
  } else {
    const unavailable = defineEventHandler((event) => {
      setResponseStatus(event, 404);
      return { error: "kernel-version unavailable" };
    });
    router.get(`${PREFIX}/kernel/versions`, unavailable);
    router.post(`${PREFIX}/kernel/switch`, unavailable);
  }
  const tunUnavailable = defineEventHandler((event) => {
    setResponseStatus(event, 404);
    return { error: "tun unavailable" };
  });
  if (tunController) {
    const { uninstall } = tunController;
    router.get(
      `${PREFIX}/tun`,
      defineEventHandler(() => tunController.status())
    );
    router.post(
      `${PREFIX}/tun`,
      defineEventHandler(async (event) => {
        var _a;
        const body = await readBody(event);
        try {
          if (body.enabled) {
            await tunController.enable({ stack: (_a = body.stack) != null ? _a : "" });
          } else {
            await tunController.disable();
          }
        } catch (err) {
          if (err instanceof TunPreconditionError) {
            throw createError$1({
              statusCode: err.statusCode,
              statusMessage: err.message,
              data: { error: err.message }
            });
          }
          throw err;
        }
        return tunController.status();
      })
    );
    router.post(
      `${PREFIX}/tun/uninstall`,
      uninstall ? defineEventHandler(async () => {
        await uninstall();
        return tunController.status();
      }) : tunUnavailable
    );
  } else {
    router.get(`${PREFIX}/tun`, tunUnavailable);
    router.post(`${PREFIX}/tun`, tunUnavailable);
    router.post(`${PREFIX}/tun/uninstall`, tunUnavailable);
  }
  app.use(router);
  return app;
}

var _a;
const MIHOMO_VERSION = (_a = process.env.MIHOMO_VERSION) != null ? _a : "v1.19.27";

async function applyActiveRefresh(profiles, supervisor, id) {
  const activeId = await profiles.getActiveId();
  if (!activeId || activeId !== id) return;
  await profiles.setActive(activeId);
  await supervisor.restart();
}

function createProfileScheduler(deps) {
  var _a, _b, _c, _d;
  const { profiles, onResult } = deps;
  const tickMs = (_a = deps.tickMs) != null ? _a : 6e4;
  const now = (_b = deps.now) != null ? _b : Date.now;
  const setTimer = (_c = deps.setTimer) != null ? _c : ((fn, ms) => setTimeout(fn, ms));
  const clearTimer = (_d = deps.clearTimer) != null ? _d : ((h) => clearTimeout(h));
  let handle;
  let running = false;
  async function tick() {
    var _a2;
    if (!running) return;
    const list = await profiles.list();
    for (const meta of list) {
      if (meta.type !== "remote") continue;
      const interval = (_a2 = meta.updateInterval) != null ? _a2 : 0;
      if (interval <= 0) continue;
      if (now() - meta.updatedAt < interval * 6e4) continue;
      try {
        await profiles.refresh(meta.id);
        onResult == null ? void 0 : onResult({ id: meta.id, ok: true });
      } catch (err) {
        onResult == null ? void 0 : onResult({
          id: meta.id,
          ok: false,
          error: err instanceof Error ? err.message : String(err)
        });
      }
    }
  }
  function arm() {
    if (!running) return;
    handle = setTimer(() => {
      void tick().finally(() => arm());
    }, tickMs);
  }
  return {
    start() {
      if (running) return;
      running = true;
      arm();
    },
    stop() {
      running = false;
      if (handle !== void 0) {
        clearTimer(handle);
        handle = void 0;
      }
    }
  };
}

const DEFAULT_TIMEOUT_MS = 5e3;
function isWhitespace$1(char) {
  return char !== void 0 && char.trim() === "";
}
function rewriteDefaultExport(code) {
  let statementBoundary = true;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = 0; i < code.length; i++) {
    const char = code[i];
    const next = code[i + 1];
    if (lineComment) {
      if (char === "\n") {
        lineComment = false;
        statementBoundary = true;
      }
      continue;
    }
    if (blockComment) {
      if (char === "*" && next === "/") {
        blockComment = false;
        i++;
      }
      continue;
    }
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (char === "\\") {
        escaped = true;
      } else if (char === quote) {
        quote = null;
      }
      continue;
    }
    if (char === "/" && next === "/") {
      lineComment = true;
      i++;
      continue;
    }
    if (char === "/" && next === "*") {
      blockComment = true;
      i++;
      continue;
    }
    if (char === "'" || char === '"' || char === "`") {
      quote = char;
      statementBoundary = false;
      continue;
    }
    if (isWhitespace$1(char)) {
      if (char === "\n" || char === "\r") statementBoundary = true;
      continue;
    }
    if (char === ";") {
      statementBoundary = true;
      continue;
    }
    if (statementBoundary && code.startsWith("export", i)) {
      let cursor = i + "export".length;
      if (!isWhitespace$1(code[cursor])) {
        statementBoundary = false;
        continue;
      }
      while (isWhitespace$1(code[cursor])) cursor++;
      if (!code.startsWith("default", cursor)) {
        statementBoundary = false;
        continue;
      }
      cursor += "default".length;
      if (!isWhitespace$1(code[cursor])) {
        statementBoundary = false;
        continue;
      }
      while (isWhitespace$1(code[cursor])) cursor++;
      return `${code.slice(0, i)}module.exports = ${code.slice(cursor)}`;
    }
    statementBoundary = false;
  }
  return code;
}
const WORKER_BOOTSTRAP = `
const { parentPort, workerData } = require('node:worker_threads')
async function main() {
  const { code, input } = workerData
  const moduleObj = { exports: {} }
  // Minimal surface: provide module/exports; do NOT forward require/fetch/fs.
  // eslint-disable-next-line no-new-func
  const factory = new Function('module', 'exports', String(code))
  factory(moduleObj, moduleObj.exports)
  const fn = moduleObj.exports
  if (typeof fn !== 'function') {
    throw new Error(
      'script profile must export a function (config) => config',
    )
  }
  const result = await fn(input)
  return result
}
main().then(
  (result) => { parentPort.postMessage({ ok: true, result }) },
  (err) => {
    parentPort.postMessage({
      ok: false,
      message: err && err.message ? String(err.message) : String(err),
    })
  },
)
`;
function runInWorker(timeoutMs) {
  return (code, input) => new Promise((resolve, reject) => {
    const worker = new Worker(WORKER_BOOTSTRAP, {
      eval: true,
      workerData: { code: rewriteDefaultExport(code), input }
    });
    let settled = false;
    const finish = (fn) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      void worker.terminate();
      fn();
    };
    const timer = setTimeout(() => {
      finish(() => reject(new Error(`script timed out after ${timeoutMs}ms`)));
    }, timeoutMs);
    worker.on("message", (msg) => {
      if (msg.ok) finish(() => resolve(msg.result));
      else finish(() => reject(new Error(msg.message)));
    });
    worker.on("error", (err) => {
      finish(
        () => reject(err instanceof Error ? err : new Error(String(err)))
      );
    });
    worker.on("exit", (codeNum) => {
      if (codeNum !== 0) {
        finish(
          () => reject(new Error(`script worker exited with code ${codeNum}`))
        );
      }
    });
  });
}
function createScriptRunner(opts = {}) {
  var _a, _b;
  const timeoutMs = (_a = opts.timeoutMs) != null ? _a : DEFAULT_TIMEOUT_MS;
  const run = (_b = opts.run) != null ? _b : runInWorker(timeoutMs);
  return { run };
}

function createMutex() {
  let tail = Promise.resolve();
  return function run(fn) {
    const result = tail.then(fn, fn);
    tail = result.catch(() => {
    });
    return result;
  };
}
function sleep(ms, now) {
  return new Promise((r) => setTimeout(r, ms));
}
const VALIDATE_KILL_GRACE_MS = 5e3;
function createSupervisor(opts, deps = {}) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
  const spawn$1 = (_a = deps.spawn) != null ? _a : spawn;
  const doFetch = (_b = deps.fetch) != null ? _b : fetch;
  const treeKill = (_c = deps.treeKill) != null ? _c : treeKillDefault;
  const now = (_d = deps.now) != null ? _d : Date.now;
  const platform = (_e = deps.platform) != null ? _e : process.platform;
  const setTimer = (_f = deps.setTimer) != null ? _f : ((fn, ms) => setTimeout(fn, ms));
  const clearTimer = (_g = deps.clearTimer) != null ? _g : ((h) => clearTimeout(h));
  const startTimeoutMs = (_h = opts.startTimeoutMs) != null ? _h : 1e4;
  const stopTimeoutMs = (_i = opts.stopTimeoutMs) != null ? _i : 5e3;
  const validateTimeoutMs = (_j = opts.validateTimeoutMs) != null ? _j : 3e5;
  const mixedPort = opts.mixedPort;
  const autoRestart = (_k = opts.autoRestart) != null ? _k : true;
  const maxRestarts = (_l = opts.maxRestarts) != null ? _l : 3;
  const restartBackoffMs = (_m = opts.restartBackoffMs) != null ? _m : 1e3;
  const stableRestartMs = (_n = opts.stableRestartMs) != null ? _n : 3e4;
  const state = {
    status: "stopped",
    externalController: (_o = opts.externalController) != null ? _o : "127.0.0.1:9090",
    secret: (_p = opts.secret) != null ? _p : randomBytes(16).toString("hex")
  };
  const logCbs = /* @__PURE__ */ new Set();
  const stateCbs = /* @__PURE__ */ new Set();
  let child;
  let binaryPath = opts.binaryPath;
  const run = createMutex();
  let intentionalStop = false;
  let restartCount = 0;
  let restartTimer;
  let stableTimer;
  function setState(patch) {
    Object.assign(state, patch);
    const snapshot = { ...state };
    for (const cb of stateCbs) cb(snapshot);
  }
  function emitLines(stream, chunk) {
    const text = chunk.toString("utf8");
    for (const line of text.split("\n")) {
      if (line.length === 0) continue;
      const l = { stream, line, ts: now() };
      for (const cb of logCbs) cb(l);
    }
  }
  function versionUrl() {
    const addr = state.externalController;
    const withScheme = addr.startsWith("http") ? addr : `http://${addr}`;
    try {
      const u = new URL(withScheme);
      const WILDCARD = /* @__PURE__ */ new Set(["0.0.0.0", "::", "[::]", ""]);
      if (WILDCARD.has(u.hostname)) u.hostname = "127.0.0.1";
      return `${u.origin}/version`;
    } catch {
      return `${withScheme}/version`;
    }
  }
  async function pollReady(deadline) {
    while (now() < deadline) {
      if (state.status === "errored") return false;
      try {
        const res = await doFetch(versionUrl(), {
          headers: state.secret ? { Authorization: `Bearer ${state.secret}` } : void 0
        });
        if (res.ok) {
          const body = await res.json().catch(() => ({}));
          setState({ status: "running", version: body.version });
          armStabilityReset();
          return true;
        }
      } catch {
      }
      await sleep(200);
    }
    return false;
  }
  function killProc(signal) {
    if (!(child == null ? void 0 : child.pid)) return;
    if (platform === "win32") {
      treeKill(child.pid, signal);
    } else {
      child.kill(signal);
    }
  }
  async function injectClashConfig() {
    let existing = "";
    if (existsSync(opts.activeConfigPath)) {
      existing = await readFile$1(opts.activeConfigPath, "utf8");
    }
    const managedKeys = /* @__PURE__ */ new Set(["external-controller", "secret", "mixed-port"]);
    const listenerPortKeys = /* @__PURE__ */ new Set([
      "port",
      "socks-port",
      "redir-port",
      "tproxy-port"
    ]);
    const shouldStripTopLevelKey = (line) => {
      const separator = line.indexOf(":");
      if (separator === -1) return false;
      const key = line.slice(0, separator).trimEnd();
      if (managedKeys.has(key)) return true;
      if (mixedPort == null || !listenerPortKeys.has(key)) return false;
      try {
        return parse(line.slice(separator + 1)) === mixedPort;
      } catch {
        return false;
      }
    };
    const kept = existing.split("\n").filter((line) => !shouldStripTopLevelKey(line)).join("\n");
    const header = [
      `external-controller: ${state.externalController}`,
      `secret: ${state.secret}`,
      ...mixedPort != null ? [`mixed-port: ${mixedPort}`] : [],
      ""
    ].join("\n");
    await writeFile$1(opts.activeConfigPath, header + kept);
  }
  function cancelStabilityReset() {
    if (stableTimer !== void 0) {
      clearTimer(stableTimer);
      stableTimer = void 0;
    }
  }
  function armStabilityReset() {
    if (!autoRestart) return;
    cancelStabilityReset();
    stableTimer = setTimer(() => {
      stableTimer = void 0;
      if (state.status === "running") restartCount = 0;
    }, stableRestartMs);
  }
  function scheduleRestart() {
    if (restartTimer !== void 0) clearTimer(restartTimer);
    restartTimer = setTimer(() => {
      restartTimer = void 0;
      void run(doStart);
    }, restartBackoffMs);
  }
  async function doStart() {
    var _a2, _b2, _c2;
    if (state.status === "running" || state.status === "starting")
      return { ...state };
    intentionalStop = false;
    setState({
      status: "starting",
      pid: void 0,
      version: void 0,
      lastError: void 0,
      lastExitCode: void 0
    });
    await injectClashConfig();
    const proc = spawn$1(binaryPath, [
      "-d",
      opts.homeDir,
      "-f",
      opts.activeConfigPath
    ]);
    child = proc;
    setState({ pid: (_a2 = proc.pid) != null ? _a2 : void 0, startedAt: now() });
    (_b2 = proc.stdout) == null ? void 0 : _b2.on("data", (c) => emitLines("stdout", c));
    (_c2 = proc.stderr) == null ? void 0 : _c2.on("data", (c) => emitLines("stderr", c));
    proc.on("exit", (code) => {
      child = void 0;
      cancelStabilityReset();
      const wasActive = state.status === "starting" || state.status === "running";
      if (wasActive) {
        setState({
          status: "errored",
          lastExitCode: code,
          pid: void 0
        });
        if (!intentionalStop && autoRestart && restartCount < maxRestarts) {
          restartCount++;
          scheduleRestart();
        }
      } else {
        setState({ status: "stopped", lastExitCode: code, pid: void 0 });
      }
    });
    proc.on("error", (err) => {
      setState({ status: "errored", lastError: err.message });
    });
    const ready = await pollReady(now() + startTimeoutMs);
    if (!ready && state.status !== "errored") {
      setState({ status: "errored", lastError: "ready timeout" });
      killProc("SIGKILL");
    }
    return { ...state };
  }
  async function doStop() {
    intentionalStop = true;
    restartCount = 0;
    if (restartTimer !== void 0) {
      clearTimer(restartTimer);
      restartTimer = void 0;
    }
    cancelStabilityReset();
    if (!child || state.status === "stopped") {
      setState({ status: "stopped" });
      return { ...state };
    }
    setState({ status: "stopping" });
    const proc = child;
    const exited = new Promise(
      (resolve) => proc.once("exit", () => resolve())
    );
    killProc("SIGTERM");
    const timer = sleep(stopTimeoutMs).then(() => "timeout");
    const winner = await Promise.race([
      exited.then(() => "exited"),
      timer
    ]);
    if (winner === "timeout") killProc("SIGKILL");
    await exited;
    child = void 0;
    setState({ status: "stopped", pid: void 0 });
    return { ...state };
  }
  const supervisor = {
    getState() {
      return { ...state };
    },
    start() {
      return run(doStart);
    },
    stop() {
      return run(doStop);
    },
    restart() {
      return run(async () => {
        await doStop();
        return doStart();
      });
    },
    setBinaryPath(path) {
      binaryPath = path;
    },
    async validate(configPath) {
      return new Promise((resolve) => {
        var _a2, _b2;
        const proc = spawn$1(binaryPath, [
          "-t",
          "-d",
          opts.homeDir,
          "-f",
          configPath
        ]);
        let out = "";
        (_a2 = proc.stdout) == null ? void 0 : _a2.on("data", (c) => out += c.toString());
        (_b2 = proc.stderr) == null ? void 0 : _b2.on("data", (c) => out += c.toString());
        let settled = false;
        let timeoutHandle;
        let killGraceHandle;
        let timedOut = false;
        const timeoutResult = () => {
          const detail = out.trim();
          return {
            valid: false,
            message: `validate timeout after ${validateTimeoutMs}ms${detail ? `
${detail}` : ""}`
          };
        };
        const finish = (result) => {
          if (settled) return false;
          settled = true;
          if (timeoutHandle !== void 0) clearTimer(timeoutHandle);
          if (killGraceHandle !== void 0) clearTimer(killGraceHandle);
          resolve(result);
          return true;
        };
        timeoutHandle = setTimer(() => {
          if (settled) return;
          timedOut = true;
          if (!proc.pid) {
            finish(timeoutResult());
            return;
          }
          try {
            killProcOf(proc, "SIGKILL");
          } catch (err) {
            out += `
${err instanceof Error ? err.message : String(err)}`;
            finish(timeoutResult());
            return;
          }
          if (!settled) {
            killGraceHandle = setTimer(
              () => finish(timeoutResult()),
              VALIDATE_KILL_GRACE_MS
            );
          }
        }, validateTimeoutMs);
        proc.on("exit", (code) => {
          finish(
            timedOut ? timeoutResult() : { valid: code === 0, message: out.trim() }
          );
        });
        proc.on("error", (err) => {
          finish(
            timedOut ? timeoutResult() : { valid: false, message: err.message }
          );
        });
      });
    },
    on(event, cb) {
      if (event === "log") logCbs.add(cb);
      else stateCbs.add(cb);
    },
    off(event, cb) {
      if (event === "log") logCbs.delete(cb);
      else stateCbs.delete(cb);
    },
    async dispose() {
      logCbs.clear();
      stateCbs.clear();
      intentionalStop = true;
      if (restartTimer !== void 0) {
        clearTimer(restartTimer);
        restartTimer = void 0;
      }
      cancelStabilityReset();
      if (child) {
        try {
          await run(doStop);
        } catch {
        }
      }
    }
  };
  function killProcOf(proc, signal) {
    if (!proc.pid) return;
    if (platform === "win32") treeKill(proc.pid, signal);
    else proc.kill(signal);
  }
  return supervisor;
}

const AGENT_VERSION = "0.0.0";
function createAgent(opts) {
  var _a;
  const profiles = createProfileStore({
    dir: opts.profilesDir,
    activeConfigPath: opts.activeConfigPath,
    // Without a runner, script profiles are silently skipped during compose —
    // the user's script transforms never apply. Default to a real one so the
    // feature works across every Runtime Form (server/desktop) out of the box.
    scriptRunner: (_a = opts.scriptRunner) != null ? _a : createScriptRunner()
  });
  const supervisor = createSupervisor(opts);
  const profileEditor = createProfileConfigEditor({
    profiles,
    supervisor,
    homeDir: opts.homeDir
  });
  const { systemProxy, kernelManager, tunController } = opts;
  const info = () => {
    var _a2;
    return {
      hasAgent: true,
      version: AGENT_VERSION,
      platform: { os: process.platform, arch: process.arch },
      kernel: {
        bundled: true,
        path: opts.binaryPath,
        // Fall back to the bundled kernel's version when the supervisor has not
        // observed a running kernel yet (fresh launch / stopped without ever
        // starting). Otherwise the dashboard shows "-" for the kernel version
        // until the kernel runs once, even though the bundled version is known.
        version: (_a2 = supervisor.getState().version) != null ? _a2 : MIHOMO_VERSION
      },
      features: [
        "profiles",
        "logs-sse",
        "kernel-control",
        // homeDir always exists, so geo-asset download is always available.
        "geo-assets",
        // WebDAV backup/restore is always available — credentials arrive per-request.
        "webdav-backup",
        // Runtime config viewer reads the activeConfigPath file — always available.
        "runtime-config",
        // Config-section editor reads/writes top-level keys of the active profile.
        "config-sections",
        "visual-config-editor",
        ...systemProxy ? ["system-proxy"] : [],
        ...kernelManager ? ["kernel-version"] : [],
        ...tunController ? ["tun"] : []
      ]
    };
  };
  const router = createControlRouter({
    supervisor,
    profiles,
    profileEditor,
    info,
    homeDir: opts.homeDir,
    activeConfigPath: opts.activeConfigPath,
    token: opts.agentToken,
    systemProxy,
    kernelManager,
    tunController
  });
  const scheduler = createProfileScheduler({
    profiles,
    onResult: (r) => {
      if (!r.ok) return;
      void applyActiveRefresh(profiles, supervisor, r.id).catch(() => {
      });
    }
  });
  return {
    supervisor,
    profiles,
    profileEditor,
    router,
    info,
    scheduler,
    systemProxy,
    kernelManager,
    tunController
  };
}

function int(value, fallback) {
  const n = value == null ? Number.NaN : Number.parseInt(value, 10);
  return Number.isFinite(n) ? n : fallback;
}
function serverEnv() {
  var _a, _b, _c, _d, _e, _f;
  return {
    controlPort: int(process.env.CONTROL_PORT, 8080),
    clashApiPort: int(process.env.CLASH_API_PORT, 9090),
    mixedPort: int(process.env.MIXED_PORT, 7890),
    dataDir: (_a = process.env.DATA_DIR) != null ? _a : "/data",
    mihomoBin: (_b = process.env.MIHOMO_BIN) != null ? _b : "/usr/local/bin/mihomo",
    controlToken: (_c = process.env.CONTROL_TOKEN) != null ? _c : "",
    clashSecret: (_d = process.env.CLASH_SECRET) != null ? _d : "",
    githubToken: (_e = process.env.GITHUB_TOKEN) != null ? _e : "",
    defaultBackendURL: (_f = process.env.DEFAULT_BACKEND_URL) != null ? _f : ""
  };
}
let agentSingleton;
function getAgent() {
  if (agentSingleton) return agentSingleton;
  const env = serverEnv();
  agentSingleton = createAgent({
    binaryPath: env.mihomoBin,
    homeDir: env.dataDir,
    profilesDir: join(env.dataDir, "profiles"),
    activeConfigPath: join(env.dataDir, "active.yaml"),
    agentToken: env.controlToken || void 0,
    // The agent's supervisor injects these into the active config before
    // spawning mihomo (per Plan 02). external-controller must bind 0.0.0.0 so
    // the published container port is reachable; secret is CLASH_SECRET.
    externalController: `0.0.0.0:${env.clashApiPort}`,
    secret: env.clashSecret,
    // Inject mixed-port too, otherwise MIXED_PORT is dead env: the supervisor
    // strips any profile mixed-port on spawn and, without a managed value, never
    // re-adds one, so the published proxy port (7890) stays closed (#2067).
    mixedPort: env.mixedPort
  });
  return agentSingleton;
}

const _b5uGWa7UFrPGhBSjezD72tG07kGn3IGJnO5eFLR8o0 = defineNitroPlugin(() => {
  const { supervisor, scheduler } = getAgent();
  console.log("[kernel] starting bundled mihomo on boot\u2026");
  supervisor.start().then(
    (s) => console.log(`[kernel] ${s.status}${s.pid ? ` (pid ${s.pid})` : ""}`)
  ).catch((err) => console.error("[kernel] failed to start on boot:", err));
  scheduler.start();
  console.log("[profiles] auto-update scheduler started");
});

const plugins = [
  _b5uGWa7UFrPGhBSjezD72tG07kGn3IGJnO5eFLR8o0
];

const assets = {
  "/200.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"14c6-3jmtfTvBRI+HIM+xZ+upu0UxDnE\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 5318,
    "path": "../public/200.html"
  },
  "/404.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"14c6-e6LHmaYqX18X9GXDqcdKgkQDUOE\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 5318,
    "path": "../public/404.html"
  },
  "/apple-touch-icon-180x180.png": {
    "type": "image/png",
    "etag": "\"4a4-4Z0xmykvh+tGSYYAt01hmJ0+eL8\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 1188,
    "path": "../public/apple-touch-icon-180x180.png"
  },
  "/config.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4f-ImrEIqBXJZKB4jijP0Xoh2VnvlY\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 79,
    "path": "../public/config.js"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"384-RDvd4+/uXDqqH19grYlxrm+vX24\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 900,
    "path": "../public/favicon.ico"
  },
  "/favicon.svg": {
    "type": "image/svg+xml",
    "etag": "\"1f83-pO9+ZHdMw4gmtPuYu2x/VdCKJgg\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 8067,
    "path": "../public/favicon.svg"
  },
  "/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"14c6-e6LHmaYqX18X9GXDqcdKgkQDUOE\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 5318,
    "path": "../public/index.html"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": "\"1bb-AUjRrDq7EsknWzr0+2/U9SXaQsw\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 443,
    "path": "../public/manifest.webmanifest"
  },
  "/maskable-icon-512x512.png": {
    "type": "image/png",
    "etag": "\"dc3-AavWhkxMPxBLQGYOpaiGgFwjF1c\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 3523,
    "path": "../public/maskable-icon-512x512.png"
  },
  "/pwa-192x192.png": {
    "type": "image/png",
    "etag": "\"654-oRPDiQDGFtO5AUgR9561K2FTlKE\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 1620,
    "path": "../public/pwa-192x192.png"
  },
  "/pwa-512x512.png": {
    "type": "image/png",
    "etag": "\"10d3-ddiKQBs8LMKGgVtlDxhcNGfNPAk\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 4307,
    "path": "../public/pwa-512x512.png"
  },
  "/pwa-64x64.png": {
    "type": "image/png",
    "etag": "\"26e-EUykjPtlsWtIc5NrvOx/10+BP/o\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 622,
    "path": "../public/pwa-64x64.png"
  },
  "/sw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"178e-zgF0nQX7zvnsvGfkZ5aYAEZARzY\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 6030,
    "path": "../public/sw.js"
  },
  "/workbox-2fbc6a65.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3ab2-qopfhM6PZXJ/QrCpZcyxeNwDC3M\"",
    "mtime": "2026-10-01T08:37:24.397Z",
    "size": 15026,
    "path": "../public/workbox-2fbc6a65.js"
  },
  "/_nuxt/1Tlhz6bA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bb-qEvVLbOXyCvAkX+2hsABnlYCF8k\"",
    "mtime": "2026-10-01T08:37:24.386Z",
    "size": 187,
    "path": "../public/_nuxt/1Tlhz6bA.js"
  },
  "/_nuxt/2dtRpRIZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"137-6cOb47B8/JzZTaanOVjaUBEcaOc\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 311,
    "path": "../public/_nuxt/2dtRpRIZ.js"
  },
  "/_nuxt/68a0inIq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cf-1Ff49cPnKGTe/VgVjiAs3qMAvi0\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 207,
    "path": "../public/_nuxt/68a0inIq.js"
  },
  "/_nuxt/6NHKHhdR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a1b7-0XWXsrLEdmtVpQ+Wca9TzmFNp/M\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 41399,
    "path": "../public/_nuxt/6NHKHhdR.js"
  },
  "/_nuxt/Aw5RLgh5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b98-LPi0W2GHdcLESbCsQLes40xYa3M\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 2968,
    "path": "../public/_nuxt/Aw5RLgh5.js"
  },
  "/_nuxt/B82b8a_2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"148-IAa7ExXTwH/MflpgIgwMUwL20hw\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 328,
    "path": "../public/_nuxt/B82b8a_2.js"
  },
  "/_nuxt/B8irFr8n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"21a-j2rtB/ZFQpGslXg7zCMtgmV84gc\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 538,
    "path": "../public/_nuxt/B8irFr8n.js"
  },
  "/_nuxt/BDY3jRY2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b8a-jK6XOLGns8WXVa/mSepb8rm8x+0\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 2954,
    "path": "../public/_nuxt/BDY3jRY2.js"
  },
  "/_nuxt/BFQOL4Dk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b395-nyIlKjezUuEpPrXC07GsKw7Hk80\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 45973,
    "path": "../public/_nuxt/BFQOL4Dk.js"
  },
  "/_nuxt/BHWHtvIV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16764-L1UBUzZ0wYORD7DpY6C8yBik9EY\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 92004,
    "path": "../public/_nuxt/BHWHtvIV.js"
  },
  "/_nuxt/BKXj4EYx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ad2-b3vT9r8FM8auqlVj1rlmDLQnOKs\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 2770,
    "path": "../public/_nuxt/BKXj4EYx.js"
  },
  "/_nuxt/BKfc0fFV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d002-IyiB3RTdVkPfNg+1ZPUPWGDuxAg\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 53250,
    "path": "../public/_nuxt/BKfc0fFV.js"
  },
  "/_nuxt/BNn7Gph1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"170-1Wk4VVa5mZT5ReJop4xK3QasoqU\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 368,
    "path": "../public/_nuxt/BNn7Gph1.js"
  },
  "/_nuxt/BOiUV-Na.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c1a4-1R/It2WS8BSPa/i3MhIVXj5a7us\"",
    "mtime": "2026-10-01T08:37:24.389Z",
    "size": 49572,
    "path": "../public/_nuxt/BOiUV-Na.js"
  },
  "/_nuxt/BT8vH0Ft.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e5-nLtpdgIkfe0YBuC1k6UTC/9n8lw\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 229,
    "path": "../public/_nuxt/BT8vH0Ft.js"
  },
  "/_nuxt/BSGdhyAA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6a28-91Kr6SUrlOYR2qAHsoDxqKGF+LU\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 27176,
    "path": "../public/_nuxt/BSGdhyAA.js"
  },
  "/_nuxt/BhQhH11s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"261f-aZdIEcwHdWKCEwHq2zuapC/iqKQ\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 9759,
    "path": "../public/_nuxt/BhQhH11s.js"
  },
  "/_nuxt/BQHZCtCu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"43ecf-xOKrpykP7ZGcAd3VC6PqvBuFync\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 278223,
    "path": "../public/_nuxt/BQHZCtCu.js"
  },
  "/_nuxt/Bblt4sWU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a380-qZ2Mbu1JIaha53Lpezz6w/uBN8I\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 41856,
    "path": "../public/_nuxt/Bblt4sWU.js"
  },
  "/_nuxt/BR9i63Ns.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a7a0-qxyak4Gj0Bghr4GrbJgd+IGNXYY\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 108448,
    "path": "../public/_nuxt/BR9i63Ns.js"
  },
  "/_nuxt/Bi72SY9n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"218-SztaPE3dRt+dRG2TOX3r3SALKfI\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 536,
    "path": "../public/_nuxt/Bi72SY9n.js"
  },
  "/_nuxt/BhcfXiAn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7655-qOHuOAY3CLG4LOq0V04lx62H/IU\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 30293,
    "path": "../public/_nuxt/BhcfXiAn.js"
  },
  "/_nuxt/BiECu8b6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"89-n/AhXr7DcBe60s9bSk8pB4qjtEM\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 137,
    "path": "../public/_nuxt/BiECu8b6.js"
  },
  "/_nuxt/Bk6b-s-H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"52f-be49HAz9bKdJ+ifto3SYS4zJOcM\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 1327,
    "path": "../public/_nuxt/Bk6b-s-H.js"
  },
  "/_nuxt/BlCl-uTX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8c-G9vb1JfT8bOaOmFb9V5/KI7nc6Q\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 140,
    "path": "../public/_nuxt/BlCl-uTX.js"
  },
  "/_nuxt/BqZpTLuP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e67-oVr15sKAimCr0JFAviagDWSauFQ\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 3687,
    "path": "../public/_nuxt/BqZpTLuP.js"
  },
  "/_nuxt/Bs4Lp4vb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e9-MIutXPJOOzOBDQbrTBUdv9Zddmc\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 233,
    "path": "../public/_nuxt/Bs4Lp4vb.js"
  },
  "/_nuxt/Button.D9vsIAbY.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"276-7cMINB0h3Fvv1bg9NojsUectCXE\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 630,
    "path": "../public/_nuxt/Button.D9vsIAbY.css"
  },
  "/_nuxt/Bv3ODJLd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14b-rOrHyh4wP7833exnEeA1avjXcew\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 331,
    "path": "../public/_nuxt/Bv3ODJLd.js"
  },
  "/_nuxt/C0mt334M.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f3a-d0ZhY1FlqBILAm9oatppMtDVPSc\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 3898,
    "path": "../public/_nuxt/C0mt334M.js"
  },
  "/_nuxt/C2Cw_qTU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9a0-WN1f5HivZf+2/rurIvC4+UIztw0\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 2464,
    "path": "../public/_nuxt/C2Cw_qTU.js"
  },
  "/_nuxt/C9DIm1NN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2d2-izqqO5jHu4Fd84zsIyJxV9m2Zd8\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 722,
    "path": "../public/_nuxt/C9DIm1NN.js"
  },
  "/_nuxt/CDL7Sl2L.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"184-WjgKGyXcx8ZV2s9IOGx7SduK4qo\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 388,
    "path": "../public/_nuxt/CDL7Sl2L.js"
  },
  "/_nuxt/CEGM4qDB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"25d-zuvAZhrh1Y0lV94AWIKNfgvGNfE\"",
    "mtime": "2026-10-01T08:37:24.390Z",
    "size": 605,
    "path": "../public/_nuxt/CEGM4qDB.js"
  },
  "/_nuxt/CHKw4Zmh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7b49-bfgBMiEg99H5H8bEItA3uJgbBy4\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 31561,
    "path": "../public/_nuxt/CHKw4Zmh.js"
  },
  "/_nuxt/BrpXmMpW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"777cf-gSV9jS6SDf+aNatybpRmcmFD2mE\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 489423,
    "path": "../public/_nuxt/BrpXmMpW.js"
  },
  "/_nuxt/CJ3NOcKd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"144ec-B/EZyfuZw5P38y+0Z7jZch7y4/g\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 83180,
    "path": "../public/_nuxt/CJ3NOcKd.js"
  },
  "/_nuxt/CJVTGQb5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4be-gnUg+baGZ9uSKrrAFb2HLYAKIQs\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 1214,
    "path": "../public/_nuxt/CJVTGQb5.js"
  },
  "/_nuxt/CNWHDsAC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1eea9-cSqpZch4ZfBUaFF2D+htWxaBZW0\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 126633,
    "path": "../public/_nuxt/CNWHDsAC.js"
  },
  "/_nuxt/CPrBGRYW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dc-nBgBx3F29qhikea/ef358Lq2oVQ\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 220,
    "path": "../public/_nuxt/CPrBGRYW.js"
  },
  "/_nuxt/CSos_PCG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"67b-kD4Wybpob0Z36eIj/Utj0xM5n8A\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 1659,
    "path": "../public/_nuxt/CSos_PCG.js"
  },
  "/_nuxt/CbQC9zmx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1126-s0vBjSahP7PIrxd9+bQC+rtf2QM\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 4390,
    "path": "../public/_nuxt/CbQC9zmx.js"
  },
  "/_nuxt/Ccqxoc3l.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c9e9-gk4OlSpOkcB233qsbTzVJgQZjb0\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 51689,
    "path": "../public/_nuxt/Ccqxoc3l.js"
  },
  "/_nuxt/CdHSI6bb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1612-CQ2j1jCqm8fELwydqhtgPqkpEss\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 5650,
    "path": "../public/_nuxt/CdHSI6bb.js"
  },
  "/_nuxt/CfTnz3M6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9202-jvpsVDGy/Sm8SVhuFIOUGMpWS8o\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 37378,
    "path": "../public/_nuxt/CfTnz3M6.js"
  },
  "/_nuxt/ChpuTB7V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"150-UycYT1YrW1coJR/JGGN6GzbiS0g\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 336,
    "path": "../public/_nuxt/ChpuTB7V.js"
  },
  "/_nuxt/ClokyNUc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b46d-IpsPaJ++0yFHG0sgI9TeCYxhg1w\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 46189,
    "path": "../public/_nuxt/ClokyNUc.js"
  },
  "/_nuxt/CoFCV76D.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d5-4aWPut3XgFTIhmA3VMuRfsHazwc\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 213,
    "path": "../public/_nuxt/CoFCV76D.js"
  },
  "/_nuxt/CpFvwhMT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"993-CJ8qJeCBbZ4hF2IsqXwp49vDw1M\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 2451,
    "path": "../public/_nuxt/CpFvwhMT.js"
  },
  "/_nuxt/CsEW6kIS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b82c-74UZcHWFDbnOIbZRXcx5KA+40gE\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 47148,
    "path": "../public/_nuxt/CsEW6kIS.js"
  },
  "/_nuxt/Cta-8CJn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f1f-Y7MEk5wTK+Vsf1NpKV5zyyMqEiU\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 3871,
    "path": "../public/_nuxt/Cta-8CJn.js"
  },
  "/_nuxt/CwzkpSY8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f4-9Dmo9noY6cYhHNYiGnpTVBn/Tts\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 500,
    "path": "../public/_nuxt/CwzkpSY8.js"
  },
  "/_nuxt/CxKJEZTX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3b0-KwVTgSjpr7q9yuEm5sgfbvLf83A\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 944,
    "path": "../public/_nuxt/CxKJEZTX.js"
  },
  "/_nuxt/D0GZLz8F.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d22-MUYbknswKIACJTMuAarg/Qi/m04\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 3362,
    "path": "../public/_nuxt/D0GZLz8F.js"
  },
  "/_nuxt/DA1NXNrU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2bb-ANW9vZaYnNUCr7FNgOd6jiN7bmE\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 699,
    "path": "../public/_nuxt/DA1NXNrU.js"
  },
  "/_nuxt/DNXaoORm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"145-O6HdndEiwgEKycXKnruMDN5Yqls\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 325,
    "path": "../public/_nuxt/DNXaoORm.js"
  },
  "/_nuxt/DNpyqHCL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3f0-avfjCjtJokT/4ixQ7bhgqHYVgmc\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 1008,
    "path": "../public/_nuxt/DNpyqHCL.js"
  },
  "/_nuxt/DPhPUZnp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1615-Ej8k+dqmVNB0SxIZ2iYXL56IMBg\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 5653,
    "path": "../public/_nuxt/DPhPUZnp.js"
  },
  "/_nuxt/DRW-0Lhn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4cc-pu8/OvGYtrGyScfooJZ05W5kpsc\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 1228,
    "path": "../public/_nuxt/DRW-0Lhn.js"
  },
  "/_nuxt/DSECQdV9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"236-YxeQpq3CKbEnOpghLLmUIBfWiyc\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 566,
    "path": "../public/_nuxt/DSECQdV9.js"
  },
  "/_nuxt/CNcAyo5y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ef4e6-1WUYpzIvjNQPcZGvxVdNIMn1WEE\"",
    "mtime": "2026-10-01T08:37:24.391Z",
    "size": 980198,
    "path": "../public/_nuxt/CNcAyo5y.js"
  },
  "/_nuxt/DVviXAF4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"362-OafhByYaecB96JIEPjNuV30LY78\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 866,
    "path": "../public/_nuxt/DVviXAF4.js"
  },
  "/_nuxt/DWzKkPxR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d7d2-EM0D/VxTMlvCuacIAOU6WBcR8U8\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 55250,
    "path": "../public/_nuxt/DWzKkPxR.js"
  },
  "/_nuxt/DbrOTKDN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c17-moIEd6pe7FtVL85oJPPVVkwxE1Q\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 3095,
    "path": "../public/_nuxt/DbrOTKDN.js"
  },
  "/_nuxt/DiKOIUNU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"205-wzdSxMDyCEEcw2+eWyXU4CO4xLY\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 517,
    "path": "../public/_nuxt/DiKOIUNU.js"
  },
  "/_nuxt/Dnhjhy0h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"130-czColAqtJ6AbcUgw6hL0MQXQUo8\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 304,
    "path": "../public/_nuxt/Dnhjhy0h.js"
  },
  "/_nuxt/DYQ9GwDN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"be9c-mrNJ7kEC/6q+lsC0ejsK8+Uk3qc\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 48796,
    "path": "../public/_nuxt/DYQ9GwDN.js"
  },
  "/_nuxt/Dr8thmOK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7d-uwGp5vVXKgJ+CuRclGJed/Et/Yw\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 125,
    "path": "../public/_nuxt/Dr8thmOK.js"
  },
  "/_nuxt/Dtb3kvwq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"360-3JKTtayAm7APqBXQSvB9Se58HpQ\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 864,
    "path": "../public/_nuxt/Dtb3kvwq.js"
  },
  "/_nuxt/Dvxiec6A.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18a2-IiXrXU7SCqEccDuy4WzBoM3fjJA\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 6306,
    "path": "../public/_nuxt/Dvxiec6A.js"
  },
  "/_nuxt/Dw0ZNsGW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2b0-GFSIjF5wb+psilFfRElV84qVUTM\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 688,
    "path": "../public/_nuxt/Dw0ZNsGW.js"
  },
  "/_nuxt/Dwq0fZCf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"26ca-yWB2/slpoLzlcUFzoAv9aKeJZAk\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 9930,
    "path": "../public/_nuxt/Dwq0fZCf.js"
  },
  "/_nuxt/DzLb8HSd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3a0-Uvhur3kexBp9vqI5KIm9tRU25Lo\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 928,
    "path": "../public/_nuxt/DzLb8HSd.js"
  },
  "/_nuxt/FV2KCbRS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cb-/OLOM2yRrevuDoQdF2lLtcrt24I\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 203,
    "path": "../public/_nuxt/FV2KCbRS.js"
  },
  "/_nuxt/HchSc2fN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"182-aQ0FN51DmjXnO/4jgzPpbRTbR54\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 386,
    "path": "../public/_nuxt/HchSc2fN.js"
  },
  "/_nuxt/Hu665HI3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"87-uAgC2nUvSlB/kE5A9iXTc+46qXM\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 135,
    "path": "../public/_nuxt/Hu665HI3.js"
  },
  "/_nuxt/JdQD6mxV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"21f-0EPKGL3Hr5rCe1JtzKHshk2T4a4\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 543,
    "path": "../public/_nuxt/JdQD6mxV.js"
  },
  "/_nuxt/Jn8V2Gb7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"110-5lP/kZmpSWLMRzMd1O7HVhbIAjo\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 272,
    "path": "../public/_nuxt/Jn8V2Gb7.js"
  },
  "/_nuxt/KAmA4PkP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"133-Q2tBsbAEWDfO16OZiv7QOoz6py4\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 307,
    "path": "../public/_nuxt/KAmA4PkP.js"
  },
  "/_nuxt/Modal.DKesUzzi.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"48e-A2oOGdVdbx1OqEysy6ojm/py5Es\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 1166,
    "path": "../public/_nuxt/Modal.DKesUzzi.css"
  },
  "/_nuxt/OnboardingEmptyState.Ct6zLkIm.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"da-Oh3mGhZXK3nx3Vktj4V8PT9sMu0\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 218,
    "path": "../public/_nuxt/OnboardingEmptyState.Ct6zLkIm.css"
  },
  "/_nuxt/PXVomhQC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"647-q5lHHJ5IAGolvkRp3ZQn3tSfgag\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 1607,
    "path": "../public/_nuxt/PXVomhQC.js"
  },
  "/_nuxt/TwemojiMozilla-flags.B12sb_Bp.woff2": {
    "type": "font/woff2",
    "etag": "\"131e4-QKb1U9t1R8SkGCMC3nbsjpvW2K8\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 78308,
    "path": "../public/_nuxt/TwemojiMozilla-flags.B12sb_Bp.woff2"
  },
  "/_nuxt/UU9igbmV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"120-hUsPwGIzg5AdO7UyaEoUIa7ZEj4\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 288,
    "path": "../public/_nuxt/UU9igbmV.js"
  },
  "/_nuxt/Dhm-f3w4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6af4b-HXXCtIsXcnyklAIPEdpd6O6cmNs\"",
    "mtime": "2026-10-01T08:37:24.392Z",
    "size": 438091,
    "path": "../public/_nuxt/Dhm-f3w4.js"
  },
  "/_nuxt/VLvKerys.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c2e3-132dNaJaq9L4gkYAm6Sq5SrKmHc\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 49891,
    "path": "../public/_nuxt/VLvKerys.js"
  },
  "/_nuxt/WOLnXXp3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ed-4SE3VM8Bx7zc+LLlnjuCLvdTu7M\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 237,
    "path": "../public/_nuxt/WOLnXXp3.js"
  },
  "/_nuxt/Yi5__zXi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"643-qHsCyAPh8/kR+3rgrL7X0hJINSo\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 1603,
    "path": "../public/_nuxt/Yi5__zXi.js"
  },
  "/_nuxt/bF6l1-kN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"496a-oY4pGfc7WTl+yQHRPtaL2kkYSgc\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 18794,
    "path": "../public/_nuxt/bF6l1-kN.js"
  },
  "/_nuxt/config.oXQmXwUK.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"84f-HSH5MX5Jis/d8wqBlSh6EWTKv54\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 2127,
    "path": "../public/_nuxt/config.oXQmXwUK.css"
  },
  "/_nuxt/connections.Cd5OCWAM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1f70-G1LaS8o9ISZ4qk8HjjympNxOQJM\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 8048,
    "path": "../public/_nuxt/connections.Cd5OCWAM.css"
  },
  "/_nuxt/codicon.DCmgc-ay.ttf": {
    "type": "font/ttf",
    "etag": "\"139d4-58fQ8Ohjcapek6AgDzlcXTeWfi4\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 80340,
    "path": "../public/_nuxt/codicon.DCmgc-ay.ttf"
  },
  "/_nuxt/control.D0LwdCdp.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1c0-QF21PzKFE/00KM8gaTGtaOVbO94\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 448,
    "path": "../public/_nuxt/control.D0LwdCdp.css"
  },
  "/_nuxt/default.5A1GF4GB.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f40-gUlbo8mcR4LSNd2g12iyTgIH8YM\"",
    "mtime": "2026-10-01T08:37:24.393Z",
    "size": 3904,
    "path": "../public/_nuxt/default.5A1GF4GB.css"
  },
  "/_nuxt/editor.d-_yvVgq.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"109cc-PuHxCUDbtqiaMCbmUbSDGnvEZro\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 68044,
    "path": "../public/_nuxt/editor.d-_yvVgq.css"
  },
  "/_nuxt/error-404.B2f2yOK1.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"980-mudSFOWZYKw6OXot2Q7pcy4Gccs\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 2432,
    "path": "../public/_nuxt/error-404.B2f2yOK1.css"
  },
  "/_nuxt/error-500.BzL8eALg.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"775-v6ussX+nnkjE41euxJbNe8aArDQ\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 1909,
    "path": "../public/_nuxt/error-500.BzL8eALg.css"
  },
  "/_nuxt/lEO0O4vV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"173-rp9Nto5jFbXNjQlwZrwig7VLiRk\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 371,
    "path": "../public/_nuxt/lEO0O4vV.js"
  },
  "/_nuxt/logs.Q2SQK0Af.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"8c-SHzvcE31G3UY4B7wGOAphHhZUVQ\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 140,
    "path": "../public/_nuxt/logs.Q2SQK0Af.css"
  },
  "/_nuxt/monaco-setup.COQM9i0P.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f6ce-+Xy2Svfr2XPdyvLRHdk5GO95WnM\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 63182,
    "path": "../public/_nuxt/monaco-setup.COQM9i0P.css"
  },
  "/_nuxt/novb-LQ7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a68-OENZg1oad95bKmyF3WfoCr9VvJI\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 2664,
    "path": "../public/_nuxt/novb-LQ7.js"
  },
  "/_nuxt/overview.CTR8EHmD.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"348-/qWeYtYjEXX78RnfDIduDtW37hU\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 840,
    "path": "../public/_nuxt/overview.CTR8EHmD.css"
  },
  "/_nuxt/proxies.BLVKTTG3.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"aee-q0BgQcruEePLPWsfTMRnYt0m+bM\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 2798,
    "path": "../public/_nuxt/proxies.BLVKTTG3.css"
  },
  "/_nuxt/rules.B5NWNgq3.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"151-ogtW80PpK5cgNliPclR8/B5SRps\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 337,
    "path": "../public/_nuxt/rules.B5NWNgq3.css"
  },
  "/_nuxt/editor.worker-hV6wJDRp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3f6d2-dEQUhsq6HHpfZDQ3wLXRzgeQUPw\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 259794,
    "path": "../public/_nuxt/editor.worker-hV6wJDRp.js"
  },
  "/_nuxt/entry.VifaWBx5.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4b5d5-Apk9Kql4Y3Ny2J2gSXKfWbv0jRc\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 308693,
    "path": "../public/_nuxt/entry.VifaWBx5.css"
  },
  "/_nuxt/traffic.BZwB8MEO.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"ae-DE6zRWzhrcYTLQO25fAVcCEslPQ\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 174,
    "path": "../public/_nuxt/traffic.BZwB8MEO.css"
  },
  "/_nuxt/useAppearance.hvmSNszs.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"637-UTueZNB5UmCJRPbDnQVPSn1opWs\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 1591,
    "path": "../public/_nuxt/useAppearance.hvmSNszs.css"
  },
  "/_nuxt/xuVPfKi_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d5-O77GUMf/jBzSztahqANIIB0xfEk\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 469,
    "path": "../public/_nuxt/xuVPfKi_.js"
  },
  "/_nuxt/yaml.worker-DGKmOKaI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f4a6c-Sndu67JrJlTId1YYr6I+1x4zTKA\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 1002092,
    "path": "../public/_nuxt/yaml.worker-DGKmOKaI.js"
  },
  "/_nuxt/ybCNW1Ba.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5b20-0A47YMUpD88Kwu+xnlKseih1ndI\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 23328,
    "path": "../public/_nuxt/ybCNW1Ba.js"
  },
  "/_nuxt/Y1Lk6t3p.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"230550-Uv2rnx20Uw0DmiqB/Kb4qpv64C8\"",
    "mtime": "2026-10-01T08:37:24.394Z",
    "size": 2295120,
    "path": "../public/_nuxt/Y1Lk6t3p.js"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _xLROwp = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const CONTROL_PREFIX = "/api/control";
const PUBLIC_CONTROL_PATHS = /* @__PURE__ */ new Set([`${CONTROL_PREFIX}/health`]);
function isAuthorized(input) {
  const { path, authHeader, queryToken, configuredToken } = input;
  if (!path.startsWith(CONTROL_PREFIX)) return { ok: true };
  if (PUBLIC_CONTROL_PATHS.has(path)) return { ok: true };
  if (!configuredToken)
    return {
      ok: false,
      status: 503,
      message: "CONTROL_TOKEN is not configured"
    };
  const bearer = parseBearer(authHeader);
  const presented = bearer != null ? bearer : queryToken;
  if (presented && presented === configuredToken) return { ok: true };
  return { ok: false, status: 401, message: "Unauthorized" };
}
function parseBearer(header) {
  if (!header) return void 0;
  const value = header.trim();
  let separator = 0;
  while (separator < value.length && !isWhitespace(value[separator])) {
    separator++;
  }
  if (value.slice(0, separator).toLowerCase() !== "bearer") return void 0;
  let tokenStart = separator;
  while (tokenStart < value.length && isWhitespace(value[tokenStart])) {
    tokenStart++;
  }
  return tokenStart < value.length ? value.slice(tokenStart) : void 0;
}
function isWhitespace(char) {
  return char.trim() === "";
}
const _eekbEN = defineEventHandler((event) => {
  var _a, _b;
  const result = isAuthorized({
    path: (_a = event.path.split("?")[0]) != null ? _a : event.path,
    authHeader: getRequestHeader(event, "authorization"),
    queryToken: (_b = getQuery(event).token) != null ? _b : void 0,
    configuredToken: serverEnv().controlToken
  });
  if (!result.ok) {
    throw createError$1({
      statusCode: result.status,
      statusMessage: result.message
    });
  }
});

const _lazy_TSiZEB = () => import('../routes/_..._.mjs');
const _lazy_pYgLgs = () => import('../routes/api/control/_..._.mjs');
const _lazy_TmAgtH = () => import('../routes/config.js.mjs');

const handlers = [
  { route: '', handler: _xLROwp, lazy: false, middleware: true, method: undefined },
  { route: '', handler: _eekbEN, lazy: false, middleware: true, method: undefined },
  { route: '/**', handler: _lazy_TSiZEB, lazy: true, middleware: false, method: undefined },
  { route: '/api/control/**', handler: _lazy_pYgLgs, lazy: true, middleware: false, method: undefined },
  { route: '/config.js', handler: _lazy_TmAgtH, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

function defineNitroPlugin(def) {
  return def;
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { setHeader as a, serverEnv as b, createError$1 as c, defineEventHandler as d, fromNodeMiddleware as f, getAgent as g, nodeServer as n, serveStatic as s, toNodeListener as t };
//# sourceMappingURL=nitro.mjs.map
